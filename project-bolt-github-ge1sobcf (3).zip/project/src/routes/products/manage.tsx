import { createFileRoute } from '@tanstack/react-router';
import { useCallback, useEffect, useState, type FormEvent, type SyntheticEvent } from 'react';
import {
  ArrowRight,
  ExternalLink,
  LayoutGrid,
  Loader2,
  Pencil,
  Plus,
  RefreshCw,
  Trash2,
  X,
} from 'lucide-react';
import { supabase } from '@/integrations/supabase/client';
import { AdminRouteGuard } from '@/components/admin/AdminRouteGuard';

// المخطط الفعلي: categories (name, type, color, icon) و products (category_id, price, old_price, image_url, stock, description, store).
const db = supabase as any;

const MAX_UPLOAD_BYTES = 2 * 1024 * 1024;
const FALLBACK_IMAGE =
  'https://images.unsplash.com/photo-1441986300917-64674bd600d8?w=600&auto=format&fit=crop&q=80';

const CATEGORY_TYPES: { value: string; label: string }[] = [
  { value: 'shein', label: 'شحن دولي (shein)' },
  { value: 'local', label: 'محلي (local)' },
  { value: 'offer', label: 'عروض (offer)' },
];

type CategoryRow = {
  id: string;
  name: string;
  type: string;
  color: string | null;
  icon: string | null;
  sort_order: number | null;
  created_at: string | null;
};

type ProductRow = {
  id: string;
  category_id: string;
  name: string;
  price: number | null;
  old_price: number | null;
  image_url: string | null;
  stock: number | null;
  description: string | null;
  store: string | null;
  created_at: string | null;
};

type CategoryDraft = {
  name: string;
  type: string;
  color: string;
  icon: string;
};

type ProductDraft = {
  category_id: string;
  name: string;
  price: string;
  old_price: string;
  image_url: string;
  stock: string;
  description: string;
};

const blankCategoryDraft: CategoryDraft = {
  name: '',
  type: 'shein',
  color: '#0F4C81',
  icon: 'truck',
};

const blankProductDraft: ProductDraft = {
  category_id: '',
  name: '',
  price: '0',
  old_price: '',
  image_url: '',
  stock: '0',
  description: '',
};

function ProductsManageRoute() {
  return (
    <AdminRouteGuard>
      <ProductsManager />
    </AdminRouteGuard>
  );
}

export const Route = createFileRoute('/products/manage')({
  component: ProductsManageRoute,
});

function ProductsManager() {
  const [categories, setCategories] = useState<CategoryRow[]>([]);
  const [products, setProducts] = useState<ProductRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [notice, setNotice] = useState('');

  const [categoryModalOpen, setCategoryModalOpen] = useState(false);
  const [editingCategoryId, setEditingCategoryId] = useState<string | null>(null);
  const [categoryDraft, setCategoryDraft] = useState<CategoryDraft>(blankCategoryDraft);

  const [productModalOpen, setProductModalOpen] = useState(false);
  const [editingProductId, setEditingProductId] = useState<string | null>(null);
  const [productDraft, setProductDraft] = useState<ProductDraft>(blankProductDraft);

  const loadCatalog = useCallback(async () => {
    setLoading(true);
    setError('');

    try {
      const [categoriesResult, productsResult] = await Promise.all([
        db
          .from('categories')
          .select('id,name,type,color,icon,sort_order,created_at')
          .order('sort_order', { ascending: true })
          .order('created_at', { ascending: true }),
        db
          .from('products')
          .select(
            'id,category_id,name,price,old_price,image_url,stock,description,store,created_at',
          )
          .order('created_at', { ascending: false }),
      ]);

      if (categoriesResult.error) {
        setError(`تعذر تحميل الأقسام: ${categoriesResult.error.message}`);
        return;
      }
      if (productsResult.error) {
        setError(`تعذر تحميل المنتجات: ${productsResult.error.message}`);
        return;
      }

      setCategories((categoriesResult.data ?? []) as CategoryRow[]);
      setProducts((productsResult.data ?? []) as ProductRow[]);
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : 'خطأ غير معروف';
      setError(`تعذر الاتصال بقاعدة البيانات: ${message}`);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadCatalog();
  }, [loadCatalog]);

  const updateCategoryDraft = (key: keyof CategoryDraft, value: string) => {
    setCategoryDraft((current) => ({ ...current, [key]: value }));
  };

  const updateProductDraft = (key: keyof ProductDraft, value: string) => {
    setProductDraft((current) => ({ ...current, [key]: value }));
  };

  const openNewCategoryModal = () => {
    setEditingCategoryId(null);
    setCategoryDraft(blankCategoryDraft);
    setError('');
    setNotice('');
    setCategoryModalOpen(true);
  };

  const openEditCategoryModal = (category: CategoryRow) => {
    setEditingCategoryId(category.id);
    setCategoryDraft({
      name: category.name ?? '',
      type: category.type ?? 'shein',
      color: category.color ?? '',
      icon: category.icon ?? '',
    });
    setError('');
    setNotice('');
    setCategoryModalOpen(true);
  };

  const saveCategory = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (busy) return;

    const name = categoryDraft.name.trim();
    if (!name) {
      setError('اكتب اسم القسم.');
      return;
    }

    setBusy(true);
    setError('');
    setNotice('');

    const values = {
      name,
      type: categoryDraft.type,
      color: categoryDraft.color.trim() || null,
      icon: categoryDraft.icon.trim() || null,
    };

    try {
      const result = editingCategoryId
        ? await db
            .from('categories')
            .update(values)
            .eq('id', editingCategoryId)
            .select('id,name,type,color,icon,sort_order,created_at')
            .maybeSingle()
        : await db
            .from('categories')
            .insert(values)
            .select('id,name,type,color,icon,sort_order,created_at')
            .single();

      if (result.error) {
        setError(`تعذر حفظ القسم: ${result.error.message}`);
        return;
      }
      if (!result.data) {
        setError('لم يتم الحفظ. تحقق من دور المدير وسياسات RLS.');
        return;
      }

      const savedRow = result.data as CategoryRow;
      if (editingCategoryId) {
        setCategories((current) =>
          current.map((row) => (row.id === editingCategoryId ? savedRow : row)),
        );
        setNotice('تم تحديث القسم.');
      } else {
        setCategories((current) => [...current, savedRow]);
        setNotice(`تمت إضافة قسم «${savedRow.name}».`);
      }
      setCategoryModalOpen(false);
      setEditingCategoryId(null);
      setCategoryDraft(blankCategoryDraft);
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : 'خطأ غير معروف';
      setError(`حدث خطأ أثناء حفظ القسم: ${message}`);
    } finally {
      setBusy(false);
    }
  };

  const deleteCategory = async (category: CategoryRow) => {
    if (busy) return;
    const count = products.filter((product) => product.category_id === category.id).length;
    const message =
      count > 0
        ? `حذف قسم «${category.name}» سيحذف أيضًا ${count} منتج داخله. هل أنت متأكد؟`
        : `تأكيد حذف قسم «${category.name}»؟`;
    if (!window.confirm(message)) return;

    setBusy(true);
    setError('');
    setNotice('');

    try {
      const { error: deleteError } = await db
        .from('categories')
        .delete()
        .eq('id', category.id);

      if (deleteError) {
        setError(`تعذر حذف القسم: ${deleteError.message}`);
        return;
      }

      setCategories((current) => current.filter((row) => row.id !== category.id));
      setProducts((current) => current.filter((row) => row.category_id !== category.id));
      setNotice('تم حذف القسم.');
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : 'خطأ غير معروف';
      setError(`حدث خطأ أثناء حذف القسم: ${message}`);
    } finally {
      setBusy(false);
    }
  };

  const openAddProductModal = (categoryId: string) => {
    setEditingProductId(null);
    setProductDraft({ ...blankProductDraft, category_id: categoryId });
    setError('');
    setNotice('');
    setProductModalOpen(true);
  };

  const openEditProductModal = (product: ProductRow) => {
    setEditingProductId(product.id);
    setProductDraft({
      category_id: product.category_id,
      name: product.name ?? '',
      price: String(product.price ?? 0),
      old_price: product.old_price == null ? '' : String(product.old_price),
      image_url: product.image_url ?? '',
      stock: String(product.stock ?? 0),
      description: product.description ?? '',
    });
    setError('');
    setNotice('');
    setProductModalOpen(true);
  };

  const handleUpload = (event: SyntheticEvent<HTMLInputElement>) => {
    const input = event.currentTarget;
    const file = input.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setError('الملف المختار ليس صورة.');
      input.value = '';
      return;
    }
    if (file.size > MAX_UPLOAD_BYTES) {
      setError('حجم الصورة أكبر من 2 ميغابايت. اختر صورة أصغر.');
      input.value = '';
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      if (typeof reader.result === 'string') {
        setProductDraft((current) => ({ ...current, image_url: reader.result as string }));
      }
    };
    reader.onerror = () => setError('تعذر قراءة الصورة. حاول مرة أخرى.');
    reader.readAsDataURL(file);
  };

  const saveProduct = async (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (busy) return;

    const name = productDraft.name.trim();
    const price = Number(productDraft.price);
    const stock = Number(productDraft.stock);
    const oldPriceRaw = productDraft.old_price.trim();
    const oldPrice = oldPriceRaw ? Number(oldPriceRaw) : null;
    const categoryId = productDraft.category_id;

    if (!categoryId) {
      setError('اختر القسم.');
      return;
    }
    if (!name || !Number.isFinite(price) || price < 0) {
      setError('تحقق من الاسم والسعر. يجب أن يكون السعر رقمًا غير سالب.');
      return;
    }
    if (!Number.isInteger(stock) || stock < 0) {
      setError('الكمية يجب أن تكون رقمًا صحيحًا غير سالب.');
      return;
    }
    if (oldPrice != null && (!Number.isFinite(oldPrice) || oldPrice < 0)) {
      setError('السعر القديم يجب أن يكون رقمًا غير سالب.');
      return;
    }

    setBusy(true);
    setError('');
    setNotice('');

    const category = categories.find((row) => row.id === categoryId);
    const values = {
      category_id: categoryId,
      name,
      price,
      old_price: oldPrice,
      image_url: productDraft.image_url.trim() || null,
      stock,
      description: productDraft.description.trim() || null,
      store: category?.type ?? null,
    };

    try {
      const result = editingProductId
        ? await db
            .from('products')
            .update(values)
            .eq('id', editingProductId)
            .select(
              'id,category_id,name,price,old_price,image_url,stock,description,store,created_at',
            )
            .maybeSingle()
        : await db
            .from('products')
            .insert(values)
            .select(
              'id,category_id,name,price,old_price,image_url,stock,description,store,created_at',
            )
            .single();

      if (result.error) {
        setError(`تعذر حفظ المنتج: ${result.error.message}`);
        return;
      }
      if (!result.data) {
        setError('لم يتم الحفظ. تحقق من دور المدير وسياسات RLS.');
        return;
      }

      const savedRow = result.data as ProductRow;
      if (editingProductId) {
        setProducts((current) =>
          current.map((row) => (row.id === editingProductId ? savedRow : row)),
        );
        setNotice('تم تحديث المنتج.');
      } else {
        setProducts((current) => [savedRow, ...current]);
        setNotice(`تمت إضافة «${savedRow.name}» وظهر في القسم مباشرة.`);
      }
      setProductModalOpen(false);
      setEditingProductId(null);
      setProductDraft(blankProductDraft);
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : 'خطأ غير معروف';
      setError(`حدث خطأ أثناء حفظ المنتج: ${message}`);
    } finally {
      setBusy(false);
    }
  };

  const deleteProduct = async (product: ProductRow) => {
    if (busy) return;
    if (!window.confirm(`تأكيد حذف «${product.name}»؟ لا يمكن التراجع.`)) return;

    setBusy(true);
    setError('');
    setNotice('');

    try {
      const { error: deleteError } = await db
        .from('products')
        .delete()
        .eq('id', product.id);

      if (deleteError) {
        setError(`تعذر حذف المنتج: ${deleteError.message}`);
        return;
      }

      setProducts((current) => current.filter((row) => row.id !== product.id));
      setNotice('تم حذف المنتج.');
    } catch (cause) {
      const message = cause instanceof Error ? cause.message : 'خطأ غير معروف';
      setError(`حدث خطأ أثناء حذف المنتج: ${message}`);
    } finally {
      setBusy(false);
    }
  };

  const handleImageError = (event: SyntheticEvent<HTMLImageElement>) => {
    event.currentTarget.onerror = null;
    event.currentTarget.src = FALLBACK_IMAGE;
  };

  const typeLabel = (value: string | null) =>
    CATEGORY_TYPES.find((type) => type.value === value)?.label ?? value ?? '—';

  return (
    <main dir="rtl" className="min-h-screen bg-slate-50 px-4 py-6 text-slate-900 sm:px-8">
      <div className="mx-auto max-w-6xl space-y-6">
        <header className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-white p-4 shadow-sm">
          <div>
            <h1 className="text-2xl font-black">إدارة المنتجات والأقسام</h1>
            <p className="mt-1 text-sm text-slate-500">
              أنشئ الأقسام وأضف المنتجات داخلها، وعدّلها أو احذفها. ما تحفظه يظهر للعميل فورًا.
            </p>
          </div>

          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              onClick={openNewCategoryModal}
              className="inline-flex items-center gap-2 rounded-xl bg-[#10b981] px-4 py-2.5 text-sm font-black text-white hover:bg-emerald-600 disabled:opacity-50"
              disabled={busy}
            >
              <Plus className="size-4" />
              إضافة قسم جديد
            </button>
            <a
              href="/products"
              className="inline-flex items-center gap-2 rounded-xl border px-4 py-2 text-sm font-bold hover:bg-slate-50"
            >
              <ExternalLink className="size-4" />
              صفحة العميل
            </a>
            <a
              href="/admin"
              className="inline-flex items-center gap-2 rounded-xl bg-[#005696] px-4 py-2 text-sm font-bold text-white hover:bg-[#0F4C81]"
            >
              <ArrowRight className="size-4" />
              لوحة الإدارة
            </a>
          </div>
        </header>

        {error && !categoryModalOpen && !productModalOpen && (
          <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm font-bold text-red-800">
            {error}
          </p>
        )}
        {notice && !categoryModalOpen && !productModalOpen && (
          <p role="status" className="rounded-xl bg-emerald-50 p-3 text-sm font-bold text-emerald-800">
            {notice}
          </p>
        )}

        <section className="flex flex-wrap items-center justify-between gap-3 rounded-2xl border bg-white p-4 shadow-sm">
          <h2 className="flex items-center gap-2 font-black">
            <LayoutGrid className="size-5 text-[#005696]" />
            الأقسام والمنتجات
          </h2>
          <div className="flex items-center gap-3 text-sm text-slate-500">
            <span>{categories.length} قسم</span>
            <span>{products.length} منتج</span>
            <button
              type="button"
              disabled={loading || busy}
              onClick={() => void loadCatalog()}
              className="inline-flex items-center gap-2 rounded-xl border px-4 py-2 text-sm font-bold disabled:opacity-50"
            >
              <RefreshCw className={`size-4 ${loading ? 'animate-spin' : ''}`} />
              تحديث
            </button>
          </div>
        </section>

        {loading ? (
          <p role="status" className="flex items-center gap-2 p-6 text-sm text-slate-500">
            <Loader2 className="size-4 animate-spin" />
            جارٍ تحميل البيانات…
          </p>
        ) : categories.length === 0 ? (
          <p className="rounded-2xl border bg-white p-10 text-center text-sm text-slate-500">
            لا توجد أقسام بعد. اضغط «إضافة قسم جديد» لإنشاء أول قسم.
          </p>
        ) : (
          <div className="space-y-5">
            {categories.map((category) => {
              const sectionProducts = products.filter(
                (product) => product.category_id === category.id,
              );
              return (
                <section
                  key={category.id}
                  className="overflow-hidden rounded-2xl border bg-white shadow-sm"
                >
                  <div className="flex flex-wrap items-center justify-between gap-2 border-b p-4">
                    <div>
                      <h3 className="flex items-center gap-2 font-black">
                        <span
                          className="inline-block size-3 rounded-full"
                          style={{ backgroundColor: category.color || '#005696' }}
                        />
                        {category.name}
                      </h3>
                      <p className="mt-1 text-xs text-slate-500">
                        {typeLabel(category.type)} · {sectionProducts.length} منتج
                      </p>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => openAddProductModal(category.id)}
                        className="inline-flex items-center gap-1 rounded-lg bg-[#10b981] px-3 py-2 text-xs font-black text-white hover:bg-emerald-600 disabled:opacity-50"
                      >
                        <Plus className="size-3.5" />
                        إضافة منتج
                      </button>
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => openEditCategoryModal(category)}
                        className="inline-flex items-center gap-1 rounded-lg bg-amber-100 px-3 py-2 text-xs font-bold text-amber-900 disabled:opacity-50"
                      >
                        <Pencil className="size-3.5" />
                        تعديل القسم
                      </button>
                      <button
                        type="button"
                        disabled={busy}
                        onClick={() => void deleteCategory(category)}
                        className="inline-flex items-center gap-1 rounded-lg bg-rose-100 px-3 py-2 text-xs font-bold text-rose-800 disabled:opacity-50"
                      >
                        <Trash2 className="size-3.5" />
                        حذف
                      </button>
                    </div>
                  </div>

                  {sectionProducts.length === 0 ? (
                    <p className="p-6 text-sm text-slate-500">
                      لا توجد منتجات في هذا القسم بعد.
                    </p>
                  ) : (
                    <div className="grid grid-cols-1 gap-3 p-4 sm:grid-cols-2 lg:grid-cols-4">
                      {sectionProducts.map((product) => (
                        <article
                          key={product.id}
                          className="flex flex-col overflow-hidden rounded-2xl border"
                        >
                          <img
                            src={product.image_url || FALLBACK_IMAGE}
                            alt={product.name}
                            className="aspect-square w-full bg-slate-50 object-cover"
                            onError={handleImageError}
                          />
                          <div className="flex flex-1 flex-col gap-1.5 p-3 text-right">
                            <h4 className="line-clamp-2 text-sm font-black">{product.name}</h4>
                            <div className="flex items-baseline gap-2">
                              <span className="font-mono text-base font-black text-emerald-700">
                                {Number(product.price ?? 0).toLocaleString()} ر.س
                              </span>
                              {product.old_price != null && (
                                <span className="font-mono text-xs text-slate-400 line-through">
                                  {Number(product.old_price).toLocaleString()}
                                </span>
                              )}
                            </div>
                            <span className="text-[10px] font-bold text-slate-400">
                              الكمية: {product.stock ?? 0} {Number(product.stock ?? 0) > 0 ? '· متوفر' : '· غير متوفر'}
                            </span>
                            {product.description && (
                              <p className="line-clamp-2 text-xs text-slate-500">
                                {product.description}
                              </p>
                            )}

                            <div className="mt-auto flex gap-2 pt-2">
                              <button
                                type="button"
                                disabled={busy}
                                onClick={() => openEditProductModal(product)}
                                className="inline-flex flex-1 items-center justify-center gap-1 rounded-lg bg-amber-100 px-2 py-2 text-xs font-bold text-amber-900 disabled:opacity-50"
                              >
                                <Pencil className="size-3.5" />
                                تعديل
                              </button>
                              <button
                                type="button"
                                disabled={busy}
                                onClick={() => void deleteProduct(product)}
                                className="inline-flex flex-1 items-center justify-center gap-1 rounded-lg bg-rose-100 px-2 py-2 text-xs font-bold text-rose-800 disabled:opacity-50"
                              >
                                <Trash2 className="size-3.5" />
                                حذف
                              </button>
                            </div>
                          </div>
                        </article>
                      ))}
                    </div>
                  )}
                </section>
              );
            })}
          </div>
        )}
      </div>

      {categoryModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" dir="rtl">
          <div className="max-h-[92vh] w-full max-w-md space-y-3 overflow-y-auto rounded-3xl border bg-white p-5 shadow-2xl">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="flex items-center gap-2 font-black">
                <Plus className="size-5 text-[#10b981]" />
                {editingCategoryId ? 'تعديل قسم' : 'إضافة قسم جديد'}
              </h3>
              <button
                type="button"
                onClick={() => setCategoryModalOpen(false)}
                className="grid size-8 place-items-center rounded-full bg-slate-100 hover:bg-slate-200"
                aria-label="إغلاق"
              >
                <X className="size-4" />
              </button>
            </div>

            <form onSubmit={saveCategory} className="space-y-3">
              <input
                required
                maxLength={100}
                value={categoryDraft.name}
                onChange={(event) => updateCategoryDraft('name', event.target.value)}
                placeholder="اسم القسم (مثال: اختبار)"
                className="w-full rounded-xl border p-3 text-sm"
              />

              <label className="block space-y-1 text-xs font-bold text-slate-600">
                نوع القسم
                <select
                  value={categoryDraft.type}
                  onChange={(event) => updateCategoryDraft('type', event.target.value)}
                  className="mt-1 w-full rounded-xl border p-3 text-sm font-normal text-slate-900"
                >
                  {CATEGORY_TYPES.map((type) => (
                    <option key={type.value} value={type.value}>
                      {type.label}
                    </option>
                  ))}
                </select>
              </label>

              <input
                maxLength={20}
                value={categoryDraft.color}
                onChange={(event) => updateCategoryDraft('color', event.target.value)}
                placeholder="لون القسم (مثال: #0F4C81)"
                className="w-full rounded-xl border p-3 text-sm"
              />

              <input
                maxLength={30}
                value={categoryDraft.icon}
                onChange={(event) => updateCategoryDraft('icon', event.target.value)}
                placeholder="أيقونة القسم (اختياري)"
                className="w-full rounded-xl border p-3 text-sm"
              />

              {error && (
                <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm font-bold text-red-800">
                  {error}
                </p>
              )}

              <div className="flex gap-2 pt-1">
                <button
                  type="submit"
                  disabled={busy}
                  className="flex-1 rounded-xl bg-[#005696] p-3 text-sm font-black text-white disabled:opacity-50"
                >
                  {busy ? 'جارٍ الحفظ…' : editingCategoryId ? 'حفظ التعديل' : 'إضافة القسم'}
                </button>
                <button
                  type="button"
                  onClick={() => setCategoryModalOpen(false)}
                  className="rounded-xl bg-slate-100 p-3 text-sm font-bold"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {productModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" dir="rtl">
          <div className="max-h-[92vh] w-full max-w-lg space-y-3 overflow-y-auto rounded-3xl border bg-white p-5 shadow-2xl">
            <div className="flex items-center justify-between border-b pb-3">
              <h3 className="flex items-center gap-2 font-black">
                <Plus className="size-5 text-[#10b981]" />
                {editingProductId ? 'تعديل منتج' : 'إضافة منتج جديد'}
              </h3>
              <button
                type="button"
                onClick={() => setProductModalOpen(false)}
                className="grid size-8 place-items-center rounded-full bg-slate-100 hover:bg-slate-200"
                aria-label="إغلاق"
              >
                <X className="size-4" />
              </button>
            </div>

            <form onSubmit={saveProduct} className="space-y-3">
              <label className="block space-y-1 text-xs font-bold text-slate-600">
                القسم
                <select
                  value={productDraft.category_id}
                  onChange={(event) => updateProductDraft('category_id', event.target.value)}
                  className="mt-1 w-full rounded-xl border p-3 text-sm font-normal text-slate-900"
                >
                  <option value="">اختر القسم…</option>
                  {categories.map((category) => (
                    <option key={category.id} value={category.id}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </label>

              <input
                required
                maxLength={200}
                value={productDraft.name}
                onChange={(event) => updateProductDraft('name', event.target.value)}
                placeholder="اسم المنتج"
                className="w-full rounded-xl border p-3 text-sm"
              />

              <div className="grid grid-cols-2 gap-3">
                <label className="block space-y-1 text-xs font-bold text-slate-600">
                  السعر (ر.س)
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    required
                    value={productDraft.price}
                    onChange={(event) => updateProductDraft('price', event.target.value)}
                    className="mt-1 w-full rounded-xl border p-3 text-sm font-normal text-slate-900"
                  />
                </label>

                <label className="block space-y-1 text-xs font-bold text-slate-600">
                  السعر قبل الخصم (اختياري)
                  <input
                    type="number"
                    min="0"
                    step="0.01"
                    value={productDraft.old_price}
                    onChange={(event) => updateProductDraft('old_price', event.target.value)}
                    className="mt-1 w-full rounded-xl border p-3 text-sm font-normal text-slate-900"
                  />
                </label>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <label className="block space-y-1 text-xs font-bold text-slate-600">
                  الكمية المتوفرة
                  <input
                    type="number"
                    min="0"
                    step="1"
                    required
                    value={productDraft.stock}
                    onChange={(event) => updateProductDraft('stock', event.target.value)}
                    className="mt-1 w-full rounded-xl border p-3 text-sm font-normal text-slate-900"
                  />
                </label>

                <label className="block space-y-1 text-xs font-bold text-slate-600">
                  صورة المنتج (رفع)
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleUpload}
                    className="mt-1 w-full rounded-xl border p-2 text-xs font-normal text-slate-900"
                  />
                </label>
              </div>

              <input
                type="url"
                value={productDraft.image_url.startsWith('data:') ? '' : productDraft.image_url}
                onChange={(event) => updateProductDraft('image_url', event.target.value)}
                placeholder="أو الصق رابط صورة https://..."
                className="w-full rounded-xl border p-3 text-sm"
              />

              {productDraft.image_url && (
                <img
                  src={productDraft.image_url}
                  alt="معاينة صورة المنتج"
                  className="size-28 rounded-xl border object-cover"
                  onError={handleImageError}
                />
              )}

              <textarea
                maxLength={1000}
                value={productDraft.description}
                onChange={(event) => updateProductDraft('description', event.target.value)}
                placeholder="وصف المنتج (اختياري)"
                className="min-h-24 w-full resize-y rounded-xl border p-3 text-sm"
              />

              {error && (
                <p role="alert" className="rounded-xl bg-red-50 p-3 text-sm font-bold text-red-800">
                  {error}
                </p>
              )}

              <div className="flex gap-2 pt-1">
                <button
                  type="submit"
                  disabled={busy}
                  className="flex-1 rounded-xl bg-[#005696] p-3 text-sm font-black text-white disabled:opacity-50"
                >
                  {busy ? 'جارٍ الحفظ…' : editingProductId ? 'حفظ التعديل' : 'إضافة المنتج'}
                </button>
                <button
                  type="button"
                  onClick={() => setProductModalOpen(false)}
                  className="rounded-xl bg-slate-100 p-3 text-sm font-bold"
                >
                  إلغاء
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </main>
  );
}
