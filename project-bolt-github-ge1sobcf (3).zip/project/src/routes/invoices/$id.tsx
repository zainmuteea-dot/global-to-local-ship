import { useEffect, useState } from 'react';
import { createFileRoute, Link } from '@tanstack/react-router';
import { FileText, Printer, ArrowRight } from 'lucide-react';
import InvoicePrint, { type InvoiceData } from '@/components/InvoicePrint';

const fallbackInvoice: InvoiceData = {
  order_number: 'INV-20250214-001',
  customer_name: 'عبدالرحمن الشريف',
  customer_phone: '712345678',
  customer_address: 'تعز - حي الحوبان',
  items: [
    { name: 'قميص رجالي صيفي', quantity: 2, price: 45 },
    { name: 'حذاء رياضي', quantity: 1, price: 120 },
  ],
  shipping: 15,
  discount: 0,
  created_at: '2025-02-14',
};

function InvoicePage() {
  const { id } = Route.useParams();
  const [invoice, setInvoice] = useState<InvoiceData>(fallbackInvoice);
  const [state, setState] = useState<'loading' | 'ready' | 'error'>('loading');

  useEffect(() => {
    let alive = true;
    void (async () => {
      try {
        const res = await fetch(`/api/invoices/${encodeURIComponent(id)}`);
        if (!res.ok) throw new Error('failed');
        const data = (await res.json()) as InvoiceData;
        if (!alive) return;
        setInvoice(data);
        setState('ready');
      } catch {
        if (alive) setState('error');
      }
    })();
    return () => {
      alive = false;
    };
  }, [id]);

  if (state === 'loading') {
    return (
      <main className="flex min-h-screen items-center justify-center bg-slate-100">
        <p>جارٍ تحميل الفاتورة...</p>
      </main>
    );
  }

  if (state === 'error') {
    return (
      <main className="flex min-h-screen flex-col items-center justify-center gap-4 bg-slate-100">
        <p className="font-bold text-rose-600">لم يتم العثور على الفاتورة</p>
        <Link
          to="/"
          className="rounded-xl bg-[#1e4a8a] px-6 py-3 text-sm font-bold text-white"
        >
          الرجوع للرئيسية
        </Link>
      </main>
    );
  }

  return (
    <main dir="rtl" className="min-h-screen bg-slate-100 p-4 sm:p-8">
      <div className="mx-auto max-w-3xl">
        <div className="no-print mb-6 flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3">
            <span className="grid size-11 place-items-center rounded-xl bg-[#1e4a8a] text-white">
              <FileText className="size-6" />
            </span>
            <div>
              <h1 className="text-2xl font-bold text-slate-900">فاتورة</h1>
              <p className="text-sm text-slate-500">رقم الفاتورة: {invoice.order_number}</p>
            </div>
          </div>
          <button
            type="button"
            onClick={() => window.print()}
            className="inline-flex items-center gap-2 rounded-xl bg-[#1e4a8a] px-5 py-2.5 text-sm font-bold text-white shadow-md hover:bg-[#12305c]"
          >
            <Printer className="h-4 w-4" />
            طباعة الفاتورة
          </button>
          <Link
            to="/"
            className="inline-flex items-center gap-2 rounded-xl border border-slate-300 bg-white px-4 py-2 text-sm font-medium text-slate-700 hover:bg-slate-50"
          >
            <ArrowRight className="h-4 w-4" />
            الرئيسية
          </Link>
        </div>

        <InvoicePrint data={invoice} />
      </div>
    </main>
  );
}

export const Route = createFileRoute('/invoices/$id')({
  component: InvoicePage,
});
