import { useState } from "react";
import { Check, ChevronRight, LoaderCircle, Minus, Plus, ShoppingBag, Trash2, Truck } from "lucide-react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { PRODUCTS, formatPrice } from "@/lib/shop-data";
import { useShopState, changeQty, removeFromCart, clearCart } from "@/lib/shop-store";

export const Route = createFileRoute("/app/cart")({
  component: CartPage,
});

function CartPage() {
  const { cart, currency } = useShopState();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [done, setDone] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const items = cart
    .map((i) => ({ item: i, product: PRODUCTS.find((p) => p.id === i.productId)! }))
    .filter((x) => x.product);

  const total = items.reduce((sum, x) => sum + x.product.price * x.item.qty, 0);

  const submitOrder = async (e: React.FormEvent) => {
    e.preventDefault();
    if (submitting || items.length === 0) return;
    setSubmitting(true);
    setError(null);

    try {
      const { error: insertError } = await (supabase.from("app_orders" as never) as any).insert({
        customer_name: name.trim(),
        customer_phone: phone.trim(),
        customer_address: address.trim() || null,
        items: items.map((x) => ({
          id: x.product.id,
          name: x.product.name,
          store: x.product.store,
          price: x.product.price,
          qty: x.item.qty,
        })),
        total_usd: total,
        currency,
        status: "new",
      });
      if (insertError) throw insertError;

      clearCart();
      setDone(true);
    } catch (err) {
      console.error("تعذر إرسال الطلب:", err);
      setError("تعذر إرسال الطلب. تحقق من الاتصال وحاول مجددًا.");
    } finally {
      setSubmitting(false);
    }
  };

  if (done) {
    return (
      <div dir="rtl" className="grid min-h-screen place-items-center bg-[#0A2540] px-4 text-white">
        <div className="text-center">
          <span className="mx-auto grid size-20 place-items-center rounded-full bg-emerald-500/20">
            <Check className="size-10 text-emerald-400" />
          </span>
          <p className="mt-4 text-xl font-black">تم استلام طلبك بنجاح</p>
          <p className="mt-2 text-xs leading-6 text-sky-200">
            سيتواصل معك فريق السوق الشامل عبر واتساب لتأكيد الطلب وتفاصيل التوصيل
          </p>
          <Link
            to="/app"
            className="mt-6 inline-block rounded-2xl bg-gradient-to-r from-[#F97316] to-[#EA580C] px-8 py-3 text-sm font-black shadow-lg"
          >
            العودة للرئيسية
          </Link>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div dir="rtl" className="grid min-h-screen place-items-center bg-[#0A2540] px-4 text-white">
        <div className="text-center">
          <span className="mx-auto grid size-20 place-items-center rounded-3xl bg-white/5">
            <ShoppingBag className="size-10 text-slate-500" />
          </span>
          <p className="mt-4 text-lg font-black">سلتك فارغة</p>
          <p className="mt-1 text-xs text-slate-400">ابدأ التسوق وأضف منتجاتك المفضلة</p>
          <Link
            to="/app"
            className="mt-6 inline-block rounded-2xl bg-gradient-to-r from-[#F97316] to-[#EA580C] px-8 py-3 text-sm font-black shadow-lg"
          >
            ابدأ التسوق
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div dir="rtl" className="min-h-screen bg-[#0A2540] pb-56 text-white">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#071A33]/95 px-4 py-3 backdrop-blur-xl">
        <div className="mx-auto flex max-w-3xl items-center justify-between">
          <Link
            to="/app"
            className="grid size-10 place-items-center rounded-xl border border-white/15 bg-white/5"
            aria-label="رجوع"
          >
            <ChevronRight className="size-5" />
          </Link>
          <p className="text-sm font-black">سلة المشتريات ({items.length})</p>
          <button
            onClick={() => clearCart()}
            className="grid size-10 place-items-center rounded-xl border border-white/15 bg-white/5 transition hover:bg-[#F43F5E]/20 hover:text-[#FB7185]"
            aria-label="تفريغ السلة"
          >
            <Trash2 className="size-5" />
          </button>
        </div>
      </header>

      <main className="mx-auto max-w-3xl space-y-3 px-4 pt-4">
        {items.map(({ item, product }) => (
          <div
            key={product.id}
            className="flex gap-3 rounded-2xl border border-white/10 bg-white/5 p-2.5 backdrop-blur-md"
          >
            <Link to="/app/product/$id" params={{ id: product.id }} className="shrink-0">
              <img src={product.image} alt={product.name} className="size-20 rounded-xl object-cover" />
            </Link>
            <div className="flex min-w-0 flex-1 flex-col">
              <Link to="/app/product/$id" params={{ id: product.id }}>
                <p className="truncate text-sm font-bold">{product.name}</p>
              </Link>
              <p className="mt-0.5 text-xs font-black text-[#FDBA74]">
                {formatPrice(product.price, currency)}
              </p>
              <div className="mt-auto flex items-center justify-between pt-2">
                <div className="flex items-center gap-2.5 rounded-xl border border-white/15 bg-white/5 px-2 py-1">
                  <button onClick={() => changeQty(product.id, -1)} aria-label="نقص" className="grid size-6 place-items-center rounded-md bg-white/10 active:scale-90">
                    <Minus className="size-3.5" />
                  </button>
                  <span className="w-4 text-center text-xs font-black">{item.qty}</span>
                  <button onClick={() => changeQty(product.id, 1)} aria-label="زد" className="grid size-6 place-items-center rounded-md bg-white/10 active:scale-90">
                    <Plus className="size-3.5" />
                  </button>
                </div>
                <button
                  onClick={() => removeFromCart(product.id)}
                  className="grid size-8 place-items-center rounded-lg text-[#FB7185] transition hover:bg-[#F43F5E]/20"
                  aria-label="حذف"
                >
                  <Trash2 className="size-4" />
                </button>
              </div>
            </div>
          </div>
        ))}

        {/* بيانات العميل */}
        <form
          onSubmit={submitOrder}
          className="mt-5 space-y-3 rounded-3xl border border-white/10 bg-white/5 p-4 backdrop-blur-md"
        >
          <h2 className="text-sm font-black text-white">بيانات التوصيل</h2>
          <input
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="الاسم الكامل"
            required
            maxLength={100}
            className="w-full rounded-2xl border border-white/15 bg-white/10 px-4 py-3 text-sm font-bold outline-none placeholder:text-white/50 focus:border-[#F97316]/60"
          />
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="رقم الجوال / واتساب"
            required
            inputMode="tel"
            dir="ltr"
            maxLength={20}
            className="w-full rounded-2xl border border-white/15 bg-white/10 px-4 py-3 text-sm font-bold outline-none placeholder:text-white/50 focus:border-[#F97316]/60"
          />
          <input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="المحافظة / العنوان (اختياري)"
            maxLength={200}
            className="w-full rounded-2xl border border-white/15 bg-white/10 px-4 py-3 text-sm font-bold outline-none placeholder:text-white/50 focus:border-[#F97316]/60"
          />
        </form>
      </main>

      {/* ملخص الطلب */}
      <div className="fixed inset-x-0 bottom-0 border-t border-white/10 bg-[#071A33]/95 px-4 py-4 backdrop-blur-xl">
        <div className="mx-auto max-w-3xl">
          <div className="flex items-center justify-between text-sm">
            <span className="text-sky-200">الإجمالي ({items.reduce((s, x) => s + x.item.qty, 0)} منتج)</span>
            <span className="text-xl font-black text-[#FDBA74]">{formatPrice(total, currency)}</span>
          </div>
          <button
            onClick={submitOrder}
            disabled={submitting}
            className="mt-3 flex w-full items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#F97316] to-[#EA580C] py-3.5 text-sm font-black shadow-lg shadow-orange-500/30 transition hover:-translate-y-0.5 active:scale-95 disabled:opacity-60"
          >
            {submitting ? <LoaderCircle className="size-5 animate-spin" /> : <Truck className="size-5" />}
            {submitting ? "جارٍ إرسال الطلب..." : "إتمام الطلب — توصيل لباب البيت"}
          </button>
          {error && (
            <p role="alert" className="mt-2 rounded-xl bg-red-500/15 px-3 py-2 text-center text-[11px] font-bold text-red-300">
              {error}
            </p>
          )}
          <p className="mt-2 text-center text-[10px] text-sky-300/70">
            سيتواصل معك فريق السوق الشامل لتأكيد الطلب عبر واتساب
          </p>
        </div>
      </div>
    </div>
  );
}
