import { useMemo, useState } from "react";
import { Heart, ChevronRight, Search, ShoppingCart, SlidersHorizontal } from "lucide-react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { PRODUCTS, STORES, formatPrice, type Product, type StoreId } from "@/lib/shop-data";
import { useShopState, addToCart, toggleFavorite } from "@/lib/shop-store";
import { AlShamelAppLogo } from "@/components/app/AlShamelAppLogo";

export const Route = createFileRoute("/app/search")({
  validateSearch: (search: Record<string, unknown>) => ({
    q: typeof search['q'] === "string" ? search['q'] : undefined,
    store: typeof search['store'] === "string" ? (search['store'] as StoreId) : undefined,
    deal: search['deal'] === true || search['deal'] === "true" ? true : undefined,
  }),
  component: SearchPage,
});

function SearchResultCard({ product }: { product: Product }) {
  const { currency, favorites } = useShopState();
  const isFav = favorites.includes(product.id);
  const store = STORES.find((s) => s.id === product.store)!;

  return (
    <div className="flex gap-3 overflow-hidden rounded-2xl border border-white/10 bg-white/5 p-2.5 backdrop-blur-md transition hover:border-sky-400/40">
      <Link to="/app/product/$id" params={{ id: product.id }} className="shrink-0">
        <img
          src={product.image}
          alt={product.name}
          loading="lazy"
          className="size-24 rounded-xl object-cover sm:size-28"
        />
      </Link>
      <div className="flex min-w-0 flex-1 flex-col">
        <Link to="/app/product/$id" params={{ id: product.id }}>
          <p className="truncate text-sm font-bold text-white">{product.name}</p>
          <p className="truncate text-[11px] text-sky-300/70" dir="ltr">
            {product.nameEn}
          </p>
        </Link>
        <div className="mt-1 flex items-center gap-2 text-[10px] text-slate-300">
          <span className="rounded-md px-1.5 py-0.5 font-black text-white" style={{ backgroundColor: store.brandColor }}>
            {store.name}
          </span>
          <span>{product.category}</span>
        </div>
        <div className="mt-auto flex items-center justify-between pt-2">
          <p className="text-sm font-black text-[#FDBA74]">
            {formatPrice(product.price, currency)}
          </p>
          <div className="flex gap-1.5">
            <button
              onClick={() => toggleFavorite(product.id)}
              aria-label="مفضلة"
              className={`grid size-8 place-items-center rounded-full transition active:scale-90 ${
                isFav ? "bg-[#F43F5E] text-white" : "bg-white/10 text-white hover:bg-white/20"
              }`}
            >
              <Heart className={`size-3.5 ${isFav ? "fill-current" : ""}`} />
            </button>
            <button
              onClick={() => addToCart(product.id)}
              aria-label="سلة"
              className="grid size-8 place-items-center rounded-full bg-[#0F4C81] text-white transition hover:bg-[#0284C7] active:scale-90"
            >
              <ShoppingCart className="size-3.5" />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function SearchPage() {
  const { q, store: storeFilter, deal } = Route.useSearch();
  const { currency } = useShopState();
  const [query, setQuery] = useState(q ?? "");
  const [showFilters, setShowFilters] = useState(false);
  const [priceMax, setPriceMax] = useState<number>(250);
  const [minRating, setMinRating] = useState<number>(0);
  const [selectedStores, setSelectedStores] = useState<Set<StoreId>>(
    new Set(storeFilter ? [storeFilter] : []),
  );

  const results = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return PRODUCTS.filter((p) => {
      if (deal && !p.dealOfDay) return false;
      const matchesQuery =
        !needle ||
        p.name.toLowerCase().includes(needle) ||
        p.nameEn.toLowerCase().includes(needle) ||
        p.category.includes(needle) ||
        p.description.includes(needle);
      const matchesStore = selectedStores.size === 0 || selectedStores.has(p.store);
      const matchesPrice = p.price <= priceMax;
      const matchesRating = p.rating >= minRating;
      return matchesQuery && matchesStore && matchesPrice && matchesRating;
    });
  }, [query, deal, selectedStores, priceMax, minRating]);

  return (
    <div dir="rtl" className="min-h-screen bg-[#0A2540] pb-24 text-white">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#071A33]/95 backdrop-blur-xl">
        <div className="mx-auto max-w-3xl px-4 py-3">
          <div className="flex items-center gap-3">
            <Link
              to="/app"
              className="grid size-10 shrink-0 place-items-center rounded-xl border border-white/15 bg-white/5 transition hover:bg-white/15"
              aria-label="رجوع"
            >
              <ChevronRight className="size-5" />
            </Link>
            <form
              onSubmit={(e) => e.preventDefault()}
              className="relative flex-1"
            >
              <Search className="pointer-events-none absolute right-3 top-1/2 size-4.5 -translate-y-1/2 text-sky-300" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="ابحث في كل المتاجر..."
                className="w-full rounded-2xl border border-white/15 bg-white/10 py-2.5 pr-10 pl-3 text-sm font-bold text-white outline-none placeholder:text-white/60 focus:border-sky-400/60"
              />
            </form>
            <button
              onClick={() => setShowFilters((s) => !s)}
              className={`grid size-10 shrink-0 place-items-center rounded-xl border transition ${
                showFilters
                  ? "border-[#F97316] bg-[#F97316]/20 text-[#FDBA74]"
                  : "border-white/15 bg-white/5 hover:bg-white/15"
              }`}
              aria-label="الفلاتر"
            >
              <SlidersHorizontal className="size-5" />
            </button>
          </div>
        </div>
      </header>

      {showFilters && (
        <div className="mx-auto max-w-3xl border-b border-white/10 bg-[#0F2A4A]/80 px-4 py-4 backdrop-blur-xl">
          <p className="mb-2 text-xs font-black text-sky-300">السعر الأقصى: {formatPrice(priceMax, currency)}</p>
          <input
            type="range"
            min={5}
            max={250}
            step={5}
            value={priceMax}
            onChange={(e) => setPriceMax(Number(e.target.value))}
            className="w-full accent-[#F97316]"
          />
          <p className="mb-2 mt-3 text-xs font-black text-sky-300">التقييم الأدنى</p>
          <div className="flex gap-2">
            {[0, 3, 4, 4.5].map((r) => (
              <button
                key={r}
                onClick={() => setMinRating(r)}
                className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
                  minRating === r
                    ? "bg-[#F97316] text-white"
                    : "bg-white/10 text-sky-200 hover:bg-white/20"
                }`}
              >
                {r === 0 ? "الكل" : `${r}+ نجوم`}
              </button>
            ))}
          </div>
          <p className="mb-2 mt-3 text-xs font-black text-sky-300">المتاجر</p>
          <div className="flex flex-wrap gap-2">
            {STORES.map((s) => {
              const active = selectedStores.has(s.id);
              return (
                <button
                  key={s.id}
                  onClick={() => {
                    const next = new Set(selectedStores);
                    if (active) next.delete(s.id);
                    else next.add(s.id);
                    setSelectedStores(next);
                  }}
                  className={`rounded-xl px-3 py-1.5 text-xs font-bold transition ${
                    active ? "bg-[#F97316] text-white" : "bg-white/10 text-sky-200 hover:bg-white/20"
                  }`}
                >
                  {s.name}
                </button>
              );
            })}
          </div>
        </div>
      )}

      <main className="mx-auto max-w-3xl space-y-3 px-4 pt-4">
        <p className="text-xs font-bold text-sky-300">
          {results.length} نتيجة {query && `لـ "${query}"`}
        </p>
        {results.length === 0 ? (
          <div className="rounded-3xl border border-white/10 bg-white/5 p-10 text-center">
            <Search className="mx-auto size-10 text-slate-500" />
            <p className="mt-3 text-sm font-bold text-slate-300">لا توجد نتائج مطابقة</p>
            <p className="mt-1 text-xs text-slate-400">جرّب كلمات أخرى أو عدّل الفلاتر</p>
          </div>
        ) : (
          results.map((p) => <SearchResultCard key={p.id} product={p} />)
        )}
      </main>
    </div>
  );
}
