import { useMemo, useState } from "react";
import {
  ChevronLeft,
  Clock3,
  Filter,
  Home as HomeIcon,
  Heart,
  LayoutGrid,
  Search,
  Settings,
  ShoppingCart,
  Star,
  TrendingUp,
  Truck,
} from "lucide-react";
import { Link, createFileRoute, useNavigate } from "@tanstack/react-router";
import {
  CATEGORIES,
  PRODUCTS,
  STORES,
  formatPrice,
  type Product,
  type StoreId,
} from "@/lib/shop-data";
import { useShopState, addToCart, toggleFavorite } from "@/lib/shop-store";
import { AlShamelAppLogo } from "@/components/app/AlShamelAppLogo";

export const Route = createFileRoute("/app/")({
  component: AppHome,
});

function ProductCard({ product }: { product: Product }) {
  const { currency, favorites } = useShopState();
  const isFav = favorites.includes(product.id);
  const discount = product.oldPrice
    ? Math.round((1 - product.price / product.oldPrice) * 100)
    : 0;

  return (
    <div className="group relative overflow-hidden rounded-3xl border border-white/10 bg-white/5 backdrop-blur-md transition-all duration-300 hover:-translate-y-1 hover:border-sky-400/40 hover:shadow-[0_12px_40px_rgba(2,132,199,0.35)]">
      <Link to="/app/product/$id" params={{ id: product.id }} className="block">
        <div className="relative aspect-square overflow-hidden bg-slate-800">
          <img
            src={product.image}
            alt={product.name}
            loading="lazy"
            className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          />
          {discount > 0 && (
            <span className="absolute right-2 top-2 rounded-full bg-[#F97316] px-2.5 py-1 text-[11px] font-black text-white shadow-lg">
              -{discount}%
            </span>
          )}
          {product.dealOfDay && (
            <span className="absolute left-2 top-2 rounded-full bg-sky-500/90 px-2.5 py-1 text-[10px] font-black text-white shadow-lg">
              عرض اليوم
            </span>
          )}
        </div>
        <div className="p-3">
          <p className="truncate text-sm font-bold text-white">{product.name}</p>
          <p className="mt-0.5 truncate text-[11px] text-sky-300/80" dir="ltr">
            {product.nameEn}
          </p>
          <div className="mt-2 flex items-center justify-between">
            <div>
              <p className="text-base font-black text-[#FDBA74]">
                {formatPrice(product.price, currency)}
              </p>
              {product.oldPrice && (
                <p className="text-[11px] text-slate-400 line-through">
                  {formatPrice(product.oldPrice, currency)}
                </p>
              )}
            </div>
            <div className="flex items-center gap-1 text-xs text-amber-300">
              <Star className="size-3.5 fill-amber-300" />
              <span className="font-bold">{product.rating}</span>
            </div>
          </div>
        </div>
      </Link>
      <div className="absolute bottom-3 left-3 flex gap-1.5">
        <button
          onClick={() => toggleFavorite(product.id)}
          aria-label="أضف للمفضلة"
          className={`grid size-9 place-items-center rounded-full backdrop-blur-md transition-all active:scale-90 ${
            isFav ? "bg-[#F43F5E] text-white" : "bg-white/15 text-white hover:bg-white/25"
          }`}
        >
          <Heart className={`size-4 ${isFav ? "fill-current" : ""}`} />
        </button>
        <button
          onClick={() => addToCart(product.id)}
          aria-label="أضف للسلة"
          className="grid size-9 place-items-center rounded-full bg-[#0F4C81] text-white backdrop-blur-md transition-all hover:bg-[#0284C7] active:scale-90"
        >
          <ShoppingCart className="size-4" />
        </button>
      </div>
    </div>
  );
}

function AppHome() {
  const navigate = useNavigate();
  const [query, setQuery] = useState("");

  const deals = useMemo(() => PRODUCTS.filter((p) => p.dealOfDay), []);
  const trending = useMemo(() => PRODUCTS.filter((p) => p.trending), []);

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    const q = query.trim();
    if (!q) return;
    navigate({ to: "/app/search", search: { q } as never });
  };

  const openStore = (store: (typeof STORES)[number]) => {
    if (query.trim()) {
      window.open(
        `https://www.google.com/search?q=${encodeURIComponent(query.trim() + " " + store.name)}`,
        "_blank",
      );
    } else {
      navigate({ to: "/app/search", search: { store: store.id } as never });
    }
  };

  return (
    <div dir="rtl" className="min-h-screen bg-[#0A2540] pb-24 text-white">
      {/* الشريط العلوي */}
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#071A33]/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
          <AlShamelAppLogo />
          <Link
            to="/app/settings"
            className="grid size-10 place-items-center rounded-xl border border-white/15 bg-white/5 transition hover:bg-white/15"
            aria-label="الإعدادات"
          >
            <Settings className="size-5" />
          </Link>
        </div>
        {/* شريط البحث */}
        <div className="mx-auto max-w-3xl px-4 pb-3">
          <form onSubmit={submitSearch} className="relative">
            <Search className="pointer-events-none absolute right-3.5 top-1/2 size-5 -translate-y-1/2 text-sky-300" />
            <input
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="ابحث عن ساعة، جوال، ملابس..."
              className="w-full rounded-2xl border border-white/15 bg-white/10 py-3.5 pr-11 pl-24 text-sm font-bold text-white outline-none transition placeholder:text-white/60 focus:border-[#F97316]/60 focus:ring-2 focus:ring-[#F97316]/30"
            />
            <button
              type="submit"
              className="absolute left-1.5 top-1/2 -translate-y-1/2 rounded-xl bg-gradient-to-r from-[#F97316] to-[#EA580C] px-4 py-2 text-xs font-black text-white shadow-md transition hover:-translate-y-[60%] active:scale-95"
            >
              بحث
            </button>
          </form>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4">
        {/* أزرار المتاجر الستة */}
        <section className="pt-6">
          <div className="grid grid-cols-3 gap-3 sm:grid-cols-6" dir="ltr">
            {STORES.map((store) => (
              <button
                key={store.id}
                onClick={() => openStore(store)}
                className={`group relative flex h-20 flex-col items-center justify-center gap-1 overflow-hidden rounded-2xl bg-gradient-to-tr ${store.gradient} shadow-lg transition-all duration-300 hover:-translate-y-1 hover:shadow-xl active:scale-95`}
              >
                <span className="text-sm font-black text-white drop-shadow-md">{store.name}</span>
                <span className="text-[10px] font-bold text-white/80">{store.nameAr}</span>
              </button>
            ))}
          </div>
        </section>

        {/* عروض اليوم */}
        <section className="pt-8">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-lg font-black text-white">
              <Clock3 className="size-5 text-[#FDBA74]" />
              عروض اليوم
            </h2>
            <Link
              to="/app/search"
              search={{ deal: true } as never}
              className="flex items-center gap-1 text-xs font-bold text-sky-300 hover:text-[#FDBA74]"
            >
              الكل <ChevronLeft className="size-3.5" />
            </Link>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {deals.slice(0, 6).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>

        {/* منتجات رائجة */}
        <section className="pt-8">
          <div className="mb-4 flex items-center justify-between">
            <h2 className="flex items-center gap-2 text-lg font-black text-white">
              <TrendingUp className="size-5 text-[#FDBA74]" />
              منتجات رائجة
            </h2>
          </div>
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
            {trending.slice(0, 6).map((p) => (
              <ProductCard key={p.id} product={p} />
            ))}
          </div>
        </section>

        {/* خدماتنا */}
        <section className="pt-8">
          <div className="rounded-3xl border border-white/10 bg-gradient-to-l from-[#0F4C81]/60 to-[#0284C7]/40 p-5 backdrop-blur-md">
            <div className="flex items-center gap-3">
              <span className="grid size-12 shrink-0 place-items-center rounded-2xl bg-[#F97316] shadow-lg">
                <Truck className="size-6 text-white" />
              </span>
              <div>
                <p className="text-sm font-black text-white">توصيل لباب البيت</p>
                <p className="mt-0.5 text-xs text-sky-200">
                  نصل لجميع محافظات اليمن — اشترِ من أي متجر عالمي
                </p>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* الشريط السفلي */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-[#071A33]/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-3xl items-center justify-around py-2">
          <BottomTab to="/app" icon={HomeIcon} label="الرئيسية" />
          <BottomTab to="/app/search" icon={LayoutGrid} label="المتاجر" />
          <BottomTab to="/app/favorites" icon={Heart} label="المفضلة" />
          <BottomTab to="/app/cart" icon={ShoppingCart} label="السلة" />
          <BottomTab to="/app/settings" icon={Settings} label="الإعدادات" />
        </div>
      </nav>
    </div>
  );
}

function BottomTab({
  to,
  icon: Icon,
  label,
}: {
  to: string;
  icon: React.ComponentType<{ className?: string }>;
  label: string;
}) {
  return (
    <Link
      to={to as never}
      className="flex flex-col items-center gap-0.5 rounded-xl px-4 py-1.5 text-sky-200 transition hover:bg-white/10 hover:text-white [&.active]:bg-white/10 [&.active]:text-[#FDBA74]"
      activeProps={{ className: "active" }}
    >
      <Icon className="size-5" />
      <span className="text-[10px] font-bold">{label}</span>
    </Link>
  );
}

export default AppHome;
