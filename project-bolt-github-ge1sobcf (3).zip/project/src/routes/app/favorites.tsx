import { Heart, ShoppingCart, Star } from "lucide-react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { PRODUCTS, formatPrice } from "@/lib/shop-data";
import { useShopState, addToCart, toggleFavorite } from "@/lib/shop-store";

export const Route = createFileRoute("/app/favorites")({
  component: FavoritesPage,
});

function FavoritesPage() {
  const { favorites, currency } = useShopState();
  const items = PRODUCTS.filter((p) => favorites.includes(p.id));

  if (items.length === 0) {
    return (
      <div dir="rtl" className="grid min-h-screen place-items-center bg-[#0A2540] px-4 text-white">
        <div className="text-center">
          <span className="mx-auto grid size-20 place-items-center rounded-3xl bg-white/5">
            <Heart className="size-10 text-slate-500" />
          </span>
          <p className="mt-4 text-lg font-black">لا توجد منتجات مفضلة</p>
          <p className="mt-1 text-xs text-slate-400">اضغط على القلب في أي منتج لحفظه هنا</p>
          <Link
            to="/app"
            className="mt-6 inline-block rounded-2xl bg-gradient-to-r from-[#F97316] to-[#EA580C] px-8 py-3 text-sm font-black shadow-lg"
          >
            تصفح المنتجات
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div dir="rtl" className="min-h-screen bg-[#0A2540] pb-24 text-white">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#071A33]/95 px-4 py-3 backdrop-blur-xl">
        <div className="mx-auto flex max-w-3xl items-center justify-between">
          <Link
            to="/app"
            className="grid size-10 place-items-center rounded-xl border border-white/15 bg-white/5"
            aria-label="رجوع"
          >
            <svg viewBox="0 0 24 24" className="size-5" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M9 6l6 6-6 6" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
          </Link>
          <p className="text-sm font-black">المفضلة ({items.length})</p>
          <span className="size-10" />
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4 pt-4">
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {items.map((p) => {
            const discount = p.oldPrice ? Math.round((1 - p.price / p.oldPrice) * 100) : 0;
            return (
              <div
                key={p.id}
                className="overflow-hidden rounded-3xl border border-white/10 bg-white/5 backdrop-blur-md"
              >
                <Link to="/app/product/$id" params={{ id: p.id }} className="relative block">
                  <img src={p.image} alt={p.name} loading="lazy" className="aspect-square w-full object-cover" />
                  {discount > 0 && (
                    <span className="absolute right-2 top-2 rounded-full bg-[#F97316] px-2 py-0.5 text-[10px] font-black">
                      -{discount}%
                    </span>
                  )}
                </Link>
                <div className="p-2.5">
                  <Link to="/app/product/$id" params={{ id: p.id }}>
                    <p className="truncate text-xs font-bold">{p.name}</p>
                  </Link>
                  <div className="mt-1.5 flex items-center justify-between">
                    <p className="text-sm font-black text-[#FDBA74]">{formatPrice(p.price, currency)}</p>
                    <span className="flex items-center gap-0.5 text-[10px] text-amber-300">
                      <Star className="size-3 fill-amber-300" />
                      {p.rating}
                    </span>
                  </div>
                  <div className="mt-2 flex gap-1.5">
                    <button
                      onClick={() => toggleFavorite(p.id)}
                      className="flex flex-1 items-center justify-center gap-1 rounded-xl bg-[#F43F5E]/20 py-2 text-[10px] font-black text-[#FB7185] transition active:scale-95"
                    >
                      <Heart className="size-3.5 fill-current" />
                      إزالة
                    </button>
                    <button
                      onClick={() => addToCart(p.id)}
                      className="flex flex-1 items-center justify-center gap-1 rounded-xl bg-[#0F4C81] py-2 text-[10px] font-black text-white transition active:scale-95"
                    >
                      <ShoppingCart className="size-3.5" />
                      للسلة
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </main>
    </div>
  );
}
