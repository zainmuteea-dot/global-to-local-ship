import { useState } from "react";
import {
  Check,
  ChevronRight,
  ExternalLink,
  Heart,
  Minus,
  Plus,
  ShoppingCart,
  Star,
  Truck,
} from "lucide-react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { PRODUCTS, buildAffiliateLink, formatPrice, getStore } from "@/lib/shop-data";
import { useShopState, addToCart, toggleFavorite } from "@/lib/shop-store";

export const Route = createFileRoute("/app/product/$id")({
  component: ProductPage,
});

function ProductPage() {
  const { id } = Route.useParams();
  const product = PRODUCTS.find((p) => p.id === id);
  const { currency, favorites } = useShopState();
  const [qty, setQty] = useState(1);
  const [added, setAdded] = useState(false);
  const [imgIndex, setImgIndex] = useState(0);

  if (!product) {
    return (
      <div dir="rtl" className="grid min-h-screen place-items-center bg-[#0A2540] text-white">
        <div className="text-center">
          <p className="text-xl font-black">المنتج غير موجود</p>
          <Link to="/app" className="mt-4 inline-block rounded-xl bg-[#0F4C81] px-5 py-2.5 text-sm font-black">
            العودة للرئيسية
          </Link>
        </div>
      </div>
    );
  }

  const store = getStore(product.store);
  const isFav = favorites.includes(product.id);
  const images = [product.image, product.image, product.image];
  const discount = product.oldPrice
    ? Math.round((1 - product.price / product.oldPrice) * 100)
    : 0;
  const affiliateUrl = buildAffiliateLink(product.store, product.nameEn);

  const handleAddToCart = () => {
    addToCart(product.id, qty);
    setAdded(true);
    setTimeout(() => setAdded(false), 2000);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-[#0A2540] pb-40 text-white">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#071A33]/95 backdrop-blur-xl">
        <div className="mx-auto flex max-w-3xl items-center justify-between px-4 py-3">
          <Link
            to="/app"
            className="grid size-10 place-items-center rounded-xl border border-white/15 bg-white/5 transition hover:bg-white/15"
            aria-label="رجوع"
          >
            <ChevronRight className="size-5" />
          </Link>
          <p className="truncate text-sm font-black text-white">{store.nameAr}</p>
          <Link
            to="/app/cart"
            className="grid size-10 place-items-center rounded-xl border border-white/15 bg-white/5 transition hover:bg-white/15"
            aria-label="السلة"
          >
            <ShoppingCart className="size-5" />
          </Link>
        </div>
      </header>

      <main className="mx-auto max-w-3xl px-4">
        {/* معرض الصور */}
        <section className="pt-4">
          <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-slate-800">
            <img
              src={images[imgIndex]}
              alt={product.name}
              className="aspect-square w-full object-cover"
            />
            {discount > 0 && (
              <span className="absolute right-3 top-3 rounded-full bg-[#F97316] px-3 py-1.5 text-sm font-black shadow-lg">
                خصم {discount}%
              </span>
            )}
          </div>
          <div className="mt-3 flex justify-center gap-2" dir="ltr">
            {images.map((_, i) => (
              <button
                key={i}
                onClick={() => setImgIndex(i)}
                aria-label={`صورة ${i + 1}`}
                className={`size-2.5 rounded-full transition-all ${
                  imgIndex === i ? "w-6 bg-[#F97316]" : "bg-white/30"
                }`}
              />
            ))}
          </div>
        </section>

        {/* المعلومات */}
        <section className="pt-5">
          <div className="flex items-start justify-between gap-3">
            <div className="min-w-0">
              <h1 className="text-lg font-black leading-snug text-white">{product.name}</h1>
              <p className="mt-1 text-xs text-sky-300/80" dir="ltr">{product.nameEn}</p>
            </div>
            <button
              onClick={() => toggleFavorite(product.id)}
              className={`grid size-11 shrink-0 place-items-center rounded-2xl transition active:scale-90 ${
                isFav ? "bg-[#F43F5E] text-white" : "border border-white/15 bg-white/5 hover:bg-white/15"
              }`}
              aria-label="المفضلة"
            >
              <Heart className={`size-5 ${isFav ? "fill-current" : ""}`} />
            </button>
          </div>

          <div className="mt-3 flex items-center gap-3 text-xs">
            <span className="flex items-center gap-1 text-amber-300">
              <Star className="size-4 fill-amber-300" />
              <span className="font-black">{product.rating}</span>
              <span className="text-slate-400">({product.reviews.toLocaleString("ar-YE")} تقييم)</span>
            </span>
            <span
              className="rounded-md px-2 py-0.5 font-black text-white"
              style={{ backgroundColor: store.brandColor }}
            >
              {store.name}
            </span>
          </div>

          <div className="mt-4 flex items-end gap-3">
            <p className="text-3xl font-black text-[#FDBA74]">
              {formatPrice(product.price, currency)}
            </p>
            {product.oldPrice && (
              <p className="pb-1 text-sm text-slate-400 line-through">
                {formatPrice(product.oldPrice, currency)}
              </p>
            )}
          </div>

          <p className="mt-4 text-sm leading-7 text-sky-100/90">{product.description}</p>

          {/* الكمية */}
          <div className="mt-5 flex items-center gap-4">
            <p className="text-sm font-bold text-sky-200">الكمية</p>
            <div className="flex items-center gap-3 rounded-2xl border border-white/15 bg-white/5 px-3 py-2">
              <button onClick={() => setQty((q) => Math.max(1, q - 1))} aria-label="نقص" className="grid size-7 place-items-center rounded-lg bg-white/10 transition hover:bg-white/20 active:scale-90">
                <Minus className="size-4" />
              </button>
              <span className="w-6 text-center text-sm font-black">{qty}</span>
              <button onClick={() => setQty((q) => q + 1)} aria-label="زد" className="grid size-7 place-items-center rounded-lg bg-white/10 transition hover:bg-white/20 active:scale-95">
                <Plus className="size-4" />
              </button>
            </div>
          </div>

          {/* معلومات التوصيل */}
          <div className="mt-5 flex items-center gap-3 rounded-2xl border border-white/10 bg-gradient-to-l from-[#0F4C81]/60 to-[#0284C7]/40 p-4">
            <Truck className="size-6 shrink-0 text-[#FDBA74]" />
            <p className="text-xs leading-6 text-sky-100">
              التوصيل إلى جميع محافظات اليمن خلال 15-30 يوم — الدفع عند الاستلام متاح
            </p>
          </div>
        </section>

        {/* منتجات مشابهة */}
        <section className="pt-8">
          <h2 className="mb-3 text-base font-black text-white">قد يعجبك أيضاً</h2>
          <div className="flex gap-3 overflow-x-auto pb-2">
            {PRODUCTS.filter((p) => p.id !== product.id && p.category === product.category)
              .concat(PRODUCTS.filter((p) => p.id !== product.id && p.category !== product.category))
              .slice(0, 6)
              .map((p) => (
                <Link
                  key={p.id}
                  to="/app/product/$id"
                  params={{ id: p.id }}
                  className="w-36 shrink-0 overflow-hidden rounded-2xl border border-white/10 bg-white/5 transition hover:border-sky-400/40"
                >
                  <img src={p.image} alt={p.name} loading="lazy" className="aspect-square w-full object-cover" />
                  <div className="p-2">
                    <p className="truncate text-xs font-bold text-white">{p.name}</p>
                    <p className="mt-1 text-xs font-black text-[#FDBA74]">{formatPrice(p.price, currency)}</p>
                  </div>
                </Link>
              ))}
          </div>
        </section>
      </main>

      {/* شريط الشراء السفلي */}
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-white/10 bg-[#071A33]/95 px-4 py-3 backdrop-blur-xl">
        <div className="mx-auto flex max-w-3xl gap-3">
          <button
            onClick={handleAddToCart}
            className={`flex flex-1 items-center justify-center gap-2 rounded-2xl border py-3.5 text-sm font-black transition active:scale-95 ${
              added
                ? "border-emerald-400 bg-emerald-500/20 text-emerald-300"
                : "border-white/20 bg-white/10 text-white hover:bg-white/20"
            }`}
          >
            {added ? <Check className="size-5" /> : <ShoppingCart className="size-5" />}
            {added ? "أضيف للسلة" : "أضف للسلة"}
          </button>
          <a
            href={affiliateUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="flex flex-1 items-center justify-center gap-2 rounded-2xl bg-gradient-to-r from-[#F97316] to-[#EA580C] py-3.5 text-sm font-black text-white shadow-lg shadow-orange-500/30 transition hover:-translate-y-0.5 active:scale-95"
          >
            <ExternalLink className="size-5" />
            اشترِ الآن من {store.nameAr}
          </a>
        </div>
      </div>
    </div>
  );
}
