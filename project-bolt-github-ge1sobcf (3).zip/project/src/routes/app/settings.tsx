import { useState } from "react";
import { Check, ChevronRight, Coins, Languages, Shield, Info } from "lucide-react";
import { Link, createFileRoute } from "@tanstack/react-router";
import { CURRENCIES, type CurrencyCode } from "@/lib/shop-data";
import { useShopState, setCurrency } from "@/lib/shop-store";

export const Route = createFileRoute("/app/settings")({
  component: SettingsPage,
});

function SettingsPage() {
  const { currency } = useShopState();
  const [saved, setSaved] = useState(false);

  const chooseCurrency = (code: CurrencyCode) => {
    setCurrency(code);
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  };

  return (
    <div dir="rtl" className="min-h-screen bg-[#0A2540] pb-24 text-white">
      <header className="sticky top-0 z-40 border-b border-white/10 bg-[#071A33]/95 px-4 py-3 backdrop-blur-xl">
        <div className="mx-auto flex max-w-3xl items-center justify-between">
          <Link
            to="/app"
            className="grid size-10 place-items-center rounded-xl border border-white/15 bg-white/5"
            aria-label="رجوع"
          >
            <ChevronRight className="size-5" />
          </Link>
          <p className="text-sm font-black">الإعدادات</p>
          <span className="size-10" />
        </div>
      </header>

      <main className="mx-auto max-w-3xl space-y-4 px-4 pt-4">
        {/* اللغة */}
        <section className="rounded-3xl border border-white/10 bg-white/5 p-4 backdrop-blur-md">
          <h2 className="flex items-center gap-2 text-sm font-black text-white">
            <Languages className="size-5 text-[#FDBA74]" />
            اللغة
          </h2>
          <div className="mt-3 flex items-center justify-between rounded-2xl border border-emerald-400/30 bg-emerald-500/10 px-4 py-3">
            <span className="text-sm font-bold">العربية</span>
            <Check className="size-5 text-emerald-400" />
          </div>
          <p className="mt-2 text-[11px] text-slate-400">الواجهة متاحة بالعربية حالياً (RTL)</p>
        </section>

        {/* العملة */}
        <section className="rounded-3xl border border-white/10 bg-white/5 p-4 backdrop-blur-md">
          <h2 className="flex items-center gap-2 text-sm font-black text-white">
            <Coins className="size-5 text-[#FDBA74]" />
            العملة
          </h2>
          <div className="mt-3 space-y-2">
            {(Object.keys(CURRENCIES) as CurrencyCode[]).map((code) => {
              const c = CURRENCIES[code];
              const active = currency === code;
              return (
                <button
                  key={code}
                  onClick={() => chooseCurrency(code)}
                  className={`flex w-full items-center justify-between rounded-2xl border px-4 py-3 transition active:scale-[0.98] ${
                    active
                      ? "border-[#F97316] bg-[#F97316]/15"
                      : "border-white/10 bg-white/5 hover:bg-white/10"
                  }`}
                >
                  <span className="flex items-center gap-2">
                    <span className="text-sm font-bold">{c.name}</span>
                    <span className="text-[11px] text-slate-400">{c.symbol}</span>
                  </span>
                  {active && <Check className="size-5 text-[#F97316]" />}
                </button>
              );
            })}
          </div>
          {saved && (
            <p className="mt-2 text-[11px] font-bold text-emerald-400">تم حفظ الإعدادات</p>
          )}
        </section>

        {/* حول التطبيق */}
        <section className="rounded-3xl border border-white/10 bg-white/5 p-4 backdrop-blur-md">
          <h2 className="flex items-center gap-2 text-sm font-black text-white">
            <Info className="size-5 text-[#FDBA74]" />
            حول التطبيق
          </h2>
          <div className="mt-3 space-y-1.5 text-xs text-sky-200/90">
            <p className="flex justify-between"><span>الاسم</span><span className="font-bold">السوق الشامل — AL SHAMEL</span></p>
            <p className="flex justify-between"><span>الإصدار</span><span className="font-bold">1.0.0</span></p>
            <p className="flex justify-between"><span>معرّف الحزمة</span><span className="font-bold" dir="ltr">com.alshamel.globalshopper</span></p>
          </div>
        </section>

        {/* الأمان */}
        <section className="flex items-center gap-3 rounded-3xl border border-white/10 bg-gradient-to-l from-[#0F4C81]/60 to-[#0284C7]/40 p-4">
          <Shield className="size-8 shrink-0 text-[#FDBA74]" />
          <p className="text-xs leading-6 text-sky-100">
            تسوق آمن وموثوق — جميع الطلبات تمر عبر فريق السوق الشامل المعتمد
          </p>
        </section>
      </main>
    </div>
  );
}
