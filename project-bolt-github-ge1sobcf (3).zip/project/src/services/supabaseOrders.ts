import type { OrderItem } from '@/types/orders';

const STATUS_LABELS: Record<string, string> = {
  new: 'جديد',
  reviewing: 'قيد المراجعة',
  purchased: 'تم الشراء',
  warehouse_china: 'مستودع الصين',
  international_ship: 'شحن دولي',
  shipped: 'تم الشحن',
  delivered: 'تم التسليم',
  cancelled: 'ملغي',
};

export const OrdersService = {
  getLocalOrders(): OrderItem[] {
    if (typeof window === 'undefined') return [];
    try {
      const raw = localStorage.getItem('alsouk_orders');
      if (!raw) return [];
      const parsed = JSON.parse(raw);
      return Array.isArray(parsed) ? (parsed as OrderItem[]) : [];
    } catch {
      return [];
    }
  },

  async getOrderByNumberOrPhone(
    orderNumber: string,
    phone: string,
  ): Promise<OrderItem | null> {
    const orders = this.getLocalOrders();
    const byNumber = orderNumber
      ? orders.find((o) => o.orderNumber === orderNumber)
      : undefined;
    if (byNumber) return byNumber;
    if (!phone) return null;
    return (
      orders.find((o) => (o.customerPhone ?? '').includes(phone)) ?? null
    );
  },

  async updateOrder(
    id: string,
    patch: Partial<OrderItem>,
  ): Promise<OrderItem | null> {
    if (typeof window === 'undefined') return null;
    const orders = this.getLocalOrders();
    const updated = orders
      .map((o) => (o.id === id ? { ...o, ...patch } : o))
      .find((o) => o.id === id);
    if (!updated) return null;
    localStorage.setItem('alsouk_orders', JSON.stringify(orders));
    return updated;
  },

  getStatusLabel(status: string): string {
    return STATUS_LABELS[status] ?? status;
  },
};
