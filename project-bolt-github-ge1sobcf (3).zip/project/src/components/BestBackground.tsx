export default function BestBackground() {
  return (
    <div
      aria-hidden="true"
      className="pointer-events-none absolute inset-0 -z-10"
      style={{
        background:
          "radial-gradient(130% 130% at 20% 20%, #1a4a8a 0%, #0f2a5c 55%, #081a38 100%)",
        minHeight: "100vh",
      }}
    >
      {/* طبقة النقاط الشفافة */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage:
            "radial-gradient(circle, rgba(255,255,255,0.09) 1.2px, transparent 1.2px)",
          backgroundSize: "22px 22px",
          opacity: 0.8,
        }}
      />
      {/* لمعة خفيفة برتقالية من الزاوية اليمنى */}
      <div
        className="absolute inset-0"
        style={{
          background:
            "linear-gradient(135deg, transparent 60%, rgba(255,122,0,0.06) 100%)",
        }}
      />
    </div>
  );
}
