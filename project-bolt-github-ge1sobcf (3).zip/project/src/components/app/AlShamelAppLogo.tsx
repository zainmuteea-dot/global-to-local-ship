export function AlShamelAppLogo({ compact = false }: { compact?: boolean }) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="grid size-11 place-items-center rounded-2xl bg-white shadow-lg ring-2 ring-sky-400/40 transition-transform duration-300 hover:scale-105">
        <svg viewBox="0 0 64 64" className="size-7">
          <defs>
            <linearGradient id="sGrad" x1="0" y1="0" x2="1" y2="1">
              <stop offset="0%" stopColor="#0284C7" />
              <stop offset="100%" stopColor="#0A2540" />
            </linearGradient>
          </defs>
          <path
            d="M44 18c-3-4-8-6-13-6-7 0-12 4-12 10 0 12 24 8 24 20 0 6-5 10-12 10-6 0-11-2-14-7"
            fill="none"
            stroke="url(#sGrad)"
            strokeWidth="7"
            strokeLinecap="round"
          />
        </svg>
      </div>
      {!compact && (
        <div className="leading-none">
          <p className="text-base font-black tracking-tight text-white">AL SHAMEL</p>
          <p className="mt-0.5 text-[11px] font-bold text-sky-300">السوق الشامل • Global Shopper</p>
        </div>
      )}
    </div>
  );
}
