import type { CSSProperties } from "react";

type Testimonial = {
  name: string;
  city: string;
  text: string;
};

const testimonials: Testimonial[] = [
  {
    name: "يوسف الحنفي",
    city: "صنعاء",
    text: "اشتريت لعبتين للأولاد من شي إن، التعامل كان راقي وسريع والتوصيل وصل لباب البيت بدون أي عناء.",
  },
  {
    name: "أمة الحكيمي",
    city: "عدن",
    text: "وأخيراً لقينا وسيط شحن رسمي وموثوق يوصل لعدن! خدمة ممتازة وتجاوب فوري عبر الواتساب.",
  },
  {
    name: "ياسر باشديد",
    city: "حضرموت",
    text: "التجربة فاقت التوقعات، تتبعت شحنتي خطوة بخطوة والتغليف كان فائق الجودة والحماية.",
  },
];

const divider: CSSProperties = {
  height: "1px",
  margin: "14px auto 0",
  maxWidth: "160px",
  background:
    "linear-gradient(90deg, transparent, rgba(255,140,0,0.8), rgba(103,232,249,0.8), transparent)",
};

export default function ReviewsBest() {
  return (
    <section className="fx-steps-section" dir="rtl">
      <div
        style={{
          textAlign: "center",
          paddingTop: "30px",
        }}
      >
        <div
          aria-hidden="true"
          style={{
            color: "#ff9500",
            fontSize: "22px",
            letterSpacing: "6px",
            textShadow: "0 0 14px rgba(255,149,0,0.8)",
            marginBottom: "6px",
          }}
        >
          ★★★★★
        </div>
        <h2 className="fx-steps-title" style={{ paddingTop: 0 }}>
          آراء وتجارب عملائنا الكرام
        </h2>
      </div>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(3, 1fr)",
          gap: "20px",
          maxWidth: "1100px",
          margin: "0 auto",
          padding: "28px 20px 36px",
        }}
      >
        {testimonials.map((t, i) => (
          <figure
            key={t.name}
            className="testimonial-fixed"
            style={{
              animationDelay: `${i * 0.4}s`,
              padding: "24px 20px",
              textAlign: "center",
              position: "relative",
              overflow: "visible",
              margin: 0,
            }}
          >
            <div
              aria-hidden="true"
              style={{
                color: "#ffb700",
                fontSize: "16px",
                letterSpacing: "3px",
                textShadow: "0 0 12px rgba(255,183,0,0.8)",
                marginBottom: "12px",
              }}
            >
              ★★★★★
            </div>

            <blockquote
              style={{
                color: "#ffffff",
                fontSize: "13px",
                lineHeight: 1.8,
                fontWeight: 500,
                margin: 0,
              }}
            >
              "{t.text}"
            </blockquote>

            <figcaption>
              <div style={divider} />
              <p
                style={{
                  marginTop: "12px",
                  marginBottom: "2px",
                  color: "#ffffff",
                  fontWeight: 700,
                  fontSize: "14px",
                }}
              >
                {t.name}
              </p>
              <p
                style={{
                  margin: 0,
                  color: "#ff8c00",
                  fontSize: "12px",
                  fontWeight: 700,
                }}
              >
                {t.city}
              </p>
            </figcaption>
          </figure>
        ))}
      </div>
    </section>
  );
}
