import type { CSSProperties } from "react";

type Step = {
  num: number;
  title: string;
  desc: string;
  emoji: string;
  href: string;
  wide?: boolean;
};

const steps: Step[] = [
  {
    num: 1,
    title: "أرسل الرابط",
    desc: "الصق رابط الصفحة من أي متجر إلكتروني",
    emoji: "🔗",
    href: "/new-order",
  },
  {
    num: 2,
    title: "تعرف السعر",
    desc: "نوضح لك التكلفة بالريال اليمني أو الدولار",
    emoji: "💲",
    href: "/new-order",
  },
  {
    num: 3,
    title: "نشتري لك",
    desc: "نشتري بدلاً عنك ونضمن جودة وتطابق الطلب",
    emoji: "🛒",
    href: "/new-order",
  },
  {
    num: 4,
    title: "تابع الشحنة",
    desc: "تتبع مسار شحنتك لحظة بلحظة برقم التتبع",
    emoji: "🔍",
    href: "/track",
  },
  {
    num: 5,
    title: "الاستلام",
    desc: "توصيل موثوق حتى باب بيتك في كافة المحافظات",
    emoji: "📦",
    href: "/new-order",
    wide: true,
  },
];

const iconBox: CSSProperties = {
  width: "44px",
  height: "44px",
  background: "#ff7a00",
  borderRadius: "10px",
  display: "flex",
  alignItems: "center",
  justifyContent: "center",
  flexShrink: 0,
  boxShadow: "0 4px 15px rgba(255,122,0,0.5)",
};

export default function StepsBest() {
  return (
    <section id="steps" className="fx-steps-section" dir="rtl">
      <h2 className="fx-steps-title">كيف تعمل؟ خطوات بسيطة</h2>

      <div
        style={{
          display: "grid",
          gridTemplateColumns: "repeat(2, 1fr)",
          gap: "20px",
          maxWidth: "920px",
          margin: "0 auto",
          padding: "22px 20px 10px",
        }}
      >
        {steps.map((step, i) => (
          <a
            key={step.num}
            href={step.href}
            className="card-fixed"
            style={{
              animationDelay: `${i * 0.35}s`,
              padding: "16px 18px",
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: "14px",
              position: "relative",
              overflow: "visible",
              textDecoration: "none",
              boxSizing: "border-box",
              ...(step.wide
                ? {
                    gridColumn: "1 / -1",
                    maxWidth: "460px",
                    margin: "0 auto",
                    width: "100%",
                  }
                : {}),
            }}
          >
            <span style={{ flex: 1, textAlign: "right" }}>
              <span
                style={{
                  display: "block",
                  fontSize: "14px",
                  fontWeight: 700,
                  color: "#ffffff",
                  lineHeight: 1.4,
                }}
              >
                <span style={{ color: "#ff8c00", fontWeight: 800 }}>
                  {step.num}.{" "}
                </span>
                {step.title}
              </span>
              <span
                style={{
                  display: "block",
                  marginTop: "4px",
                  color: "#cbd5e1",
                  fontSize: "12px",
                  lineHeight: 1.6,
                }}
              >
                {step.desc}
              </span>
            </span>

            <span style={iconBox}>
              <span
                aria-hidden="true"
                style={{
                  fontSize: "20px",
                  lineHeight: 1,
                  filter: "drop-shadow(0 0 8px gold)",
                }}
              >
                {step.emoji}
              </span>
            </span>
          </a>
        ))}
      </div>

      <div
        style={{
          display: "flex",
          flexWrap: "wrap",
          alignItems: "center",
          justifyContent: "center",
          gap: "12px",
          paddingBottom: "34px",
        }}
      >
        <a
          href="/new-order"
          className="fx-cta-pulse"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "8px",
            background: "linear-gradient(135deg, #ff8a2a, #ff6a00)",
            borderRadius: "12px",
            padding: "12px 26px",
            color: "#ffffff",
            fontWeight: 800,
            fontSize: "13px",
            textDecoration: "none",
            boxShadow: "0 0 22px rgba(255,122,0,0.5), 0 4px 15px rgba(255,122,0,0.35)",
          }}
        >
          <span aria-hidden="true">🛒</span>
          <span>اطلب الآن فوراً</span>
        </a>

        <a
          href="#steps"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "8px",
            background: "rgba(255,255,255,0.08)",
            backdropFilter: "blur(14px)",
            WebkitBackdropFilter: "blur(14px)",
            border: "1.5px solid rgba(103,232,249,0.5)",
            borderRadius: "12px",
            padding: "11px 22px",
            color: "#ffffff",
            fontWeight: 800,
            fontSize: "13px",
            textDecoration: "none",
            boxShadow: "0 0 14px rgba(0,255,255,0.25)",
          }}
        >
          <span aria-hidden="true">📣</span>
          <span>كيف نعمل</span>
        </a>

        <a
          href="/track"
          style={{
            display: "inline-flex",
            alignItems: "center",
            gap: "8px",
            background: "rgba(255,255,255,0.08)",
            backdropFilter: "blur(14px)",
            WebkitBackdropFilter: "blur(14px)",
            border: "1.5px solid rgba(103,232,249,0.5)",
            borderRadius: "12px",
            padding: "11px 22px",
            color: "#ffffff",
            fontWeight: 800,
            fontSize: "13px",
            textDecoration: "none",
            boxShadow: "0 0 14px rgba(0,255,255,0.25)",
          }}
        >
          <span aria-hidden="true">🔍</span>
          <span>تتبع طلبك</span>
        </a>
      </div>
    </section>
  );
}
