import { Printer, ShoppingCart, Plane, CheckCircle2 } from 'lucide-react';

export interface InvoiceLine {
  name: string;
  quantity: number;
  price: number;
}

export interface InvoiceData {
  order_number: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string;
  items: InvoiceLine[];
  shipping: number;
  discount: number;
  created_at: string;
}

interface InvoicePrintProps {
  data: InvoiceData;
}

const blue = '#1e4a8a';

export default function InvoicePrint({ data }: { data: InvoiceData }) {
  const itemsTotal = data.items.reduce((sum, item) => sum + item.price * item.quantity, 0);
  const total = Math.max(0, itemsTotal + data.shipping - data.discount);

  return (
    <div style={{ fontFamily: 'Cairo, sans-serif', background: 'white', padding: '20px', borderRadius: '16px', boxShadow: '0 4px 20px rgba(0,0,0,0.1)' }} id="print-area" dir="rtl">
      {/* الترويسة */}
      <div style={{ background: blue, color: 'white', padding: '16px 24px', display: 'flex', justifyContent: 'space-between', alignItems: 'center', borderRadius: '12px 12px 0 0' }}>
        <h1 style={{ fontSize: '22px', fontWeight: 'bold', margin: 0 }}>فاتورة / إيصال استلام</h1>
        <div style={{ textAlign: 'left' }}>
          <p className="mb-0 flex items-center gap-1"><ShoppingCart className="h-4 w-4" /> السوق الشامل</p>
          <p className="mb-0 flex items-center gap-1"><Plane className="h-4 w-4" /> للشحن الدولي</p>
        </div>
      </div>

      {/* بيانات العميل والفاتورة */}
      <div className="mt-4 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div style={{ border: '2px dashed blue', padding: '16px', borderRadius: '12px' }}>
          <h3 style={{ color: blue, fontWeight: 'bold', marginBottom: '10px' }}>معلومات العميل</h3>
          <p>اسم العميل: {data.customer_name}</p>
          <p>رقم الجوال: {data.customer_phone}</p>
          <p>العنوان: {data.customer_address}</p>
        </div>
        <div style={{ border: '2px dashed blue', padding: '16px', borderRadius: '12px' }}>
          <h3 style={{ color: 'blue', fontWeight: 'bold', marginBottom: '10px' }}>معلومات الفاتورة</h3>
          <p>رقم الطلب: {data.order_number}</p>
          <p>التاريخ: {data.created_at}</p>
          <p>عدد الأصناف: {data.items.length}</p>
          <p>
            الحالة: <span style={{ background: '#10b981', color: 'white', padding: '2px 10px', borderRadius: '10px' }}>مؤكدة</span>
          </p>
        </div>
      </div>

      {/* جدول العناصر */}
      <table style={{ width: '100%', borderCollapse: 'collapse', marginTop: '20px' }}>
        <thead>
          <tr style={{ background: blue, color: 'white' }}>
            <th style={{ padding: '10px' }}>الصنف</th>
            <th style={{ padding: '10px' }}>الكمية</th>
            <th style={{ padding: '10px' }}>السعر</th>
            <th style={{ padding: '10px' }}>المجموع</th>
          </tr>
        </thead>
        <tbody>
          {data.items.map((item, index) => (
            <tr key={index} style={{ background: index % 2 === 0 ? '#f9fafb' : 'white' }}>
              <td style={{ padding: '10px', textAlign: 'center' }}>{item.name}</td>
              <td style={{ padding: '10px', textAlign: 'center' }}>{item.quantity}</td>
              <td style={{ padding: '10px', textAlign: 'center' }}>{item.price} ر.س</td>
              <td style={{ padding: '10px', textAlign: 'center' }}>{item.price * item.quantity} ر.س</td>
            </tr>
          ))}
        </tbody>
      </table>

      {/* الملخص المالي */}
      <div className="mt-4 space-y-1 text-sm">
        <div className="flex justify-between"><span>مجموع المنتجات:</span><span>{itemsTotal} ر.س</span></div>
        <div className="flex justify-between"><span>الشحن:</span><span>{data.shipping} ر.س</span></div>
        <div className="flex justify-between"><span>الخصم:</span><span>-{data.discount} ر.س</span></div>
        <div className="mt-2 flex justify-between border-t pt-2 text-lg font-bold">
          <span>الإجمالي:</span><span>{total} ر.س</span>
        </div>
      </div>

      {/* التواقيع */}
      <div className="mt-8 grid grid-cols-1 gap-4 sm:grid-cols-2">
        <div style={{ border: '1px dashed #9ca3af', padding: '12px', borderRadius: '10px', textAlign: 'center' }}>
          <h4 className="font-bold">توقيع العميل</h4>
          <p>الاسم: ___________</p>
          <p>التاريخ: ___________</p>
        </div>
        <div style={{ border: '1px dashed #9ca3af', padding: '12px', borderRadius: '10px', textAlign: 'center' }}>
          <h4 className="font-bold">توقيع الموظف</h4>
          <p>الاسم: ___________</p>
          <p>التاريخ: ___________</p>
        </div>
      </div>

      <div className="mt-6 rounded-xl bg-sky-100 p-3 text-center text-xs">
        لخدمة العملاء والاستفسارات: 773370041 | info@alsoug-alshamel.com | صنعاء - اليمن
      </div>
    </div>
  );
}
