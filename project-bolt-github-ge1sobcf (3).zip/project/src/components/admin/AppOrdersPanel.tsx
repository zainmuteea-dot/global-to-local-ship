import { useCallback, useEffect, useState } from "react";
import { CheckCircle2, Clock, LoaderCircle, Phone, RefreshCw, ShoppingBag, X } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";

type AppOrderItem = {
  id: string;
  name: string;
  store: string;
  price: number;
  qty: number;
};

type AppOrder = {
  id: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string | null;
  items: AppOrderItem[];
  total_usd: number;
  currency: string;
  status: string;
  created_at: string;
};

const STATUS_AR: Record<string, string> = {
  new: "جديد",
  reviewing: "قيد المراجعة",
  purchased: "تم الشراء",
  shipped: "قيد الشحن",
  delivered: "تم التسليم",
  cancelled: "ملغي",
};

const STATUS_STYLES: Record<string, string> = {
  new: "bg-orange-100 text-orange-700 border-orange-200",
  reviewing: "bg-sky-100 text-sky-700 border-sky-200",
  purchased: "bg-indigo-100 text-indigo-700 border-indigo-200",
  shipped: "bg-amber-100 text-amber-700 border-amber-200",
  delivered: "bg-emerald-100 text-emerald-700 border-emerald-200",
  cancelled: "bg-red-100 text-red-700 border-red-200",
};

export function AppOrdersPanel() {
  const [orders, setOrders] = useState<AppOrder[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [updatingId, setUpdatingId] = useState<string | null>(null);

  const loadOrders = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const { data, error: fetchError } = await (supabase.from("app_orders" as never) as any)
        .select("*")
        .order("created_at", { ascending: false })
        .limit(50);
      if (fetchError) throw fetchError;
      setOrders((data ?? []) as AppOrder[]);
    } catch (err) {
      console.error("تعذر تحميل طلبات التطبيق:", err);
      setError("تعذر تحميل الطلبات. تحقق من الاتصال وحاول مجددًا.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void loadOrders();
  }, [loadOrders]);

  const changeStatus = async (orderId: string, status: string) => {
    setUpdatingId(orderId);
    try {
      const { error: updateError } = await (supabase.from("app_orders" as never) as any)
        .update({ status })
        .eq("id", orderId);
      if (updateError) throw updateError;
      setOrders((current) =>
        current.map((o) => (o.id === orderId ? { ...o, status } : o)),
      );
    } catch (err) {
      console.error("تعذر تحديث حالة الطلب:", err);
      setError("تعذر تحديث حالة الطلب.");
    } finally {
      setUpdatingId(null);
    }
  };

  return (
    <section className="rounded-2xl border border-sky-100 bg-white p-4 shadow-sm" dir="rtl">
      <div className="mb-3 flex items-center justify-between">
        <div className="flex items-center gap-2">
          <span className="grid size-9 place-items-center rounded-xl bg-orange-100 text-[#EA580C]">
            <ShoppingBag className="size-4" />
          </span>
          <div>
            <h3 className="text-sm font-black text-[#0A2540]">طلبات التطبيق</h3>
            <p className="text-[11px] text-slate-500">
              الطلبات الواردة من تطبيق السوق الشامل للجوال — {orders.length} طلب
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => void loadOrders()}
          className="grid size-9 place-items-center rounded-xl border border-slate-200 text-slate-500 transition hover:bg-slate-50"
          aria-label="تحديث"
        >
          <RefreshCw className={`size-4 ${loading ? "animate-spin" : ""}`} />
        </button>
      </div>

      {error && (
        <p role="alert" className="mb-3 rounded-xl border border-red-200 bg-red-50 p-3 text-xs font-bold text-red-800">
          {error}
        </p>
      )}

      {loading ? (
        <div className="flex items-center justify-center gap-2 py-10 text-xs font-bold text-slate-400">
          <LoaderCircle className="size-4 animate-spin" />
          جارٍ التحميل...
        </div>
      ) : orders.length === 0 ? (
        <div className="py-10 text-center">
          <ShoppingBag className="mx-auto size-8 text-slate-300" />
          <p className="mt-2 text-xs font-bold text-slate-400">لا توجد طلبات بعد</p>
        </div>
      ) : (
        <div className="space-y-3">
          {orders.map((order) => (
            <div key={order.id} className="rounded-2xl border border-slate-200 bg-slate-50/60 p-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="text-xs font-black text-[#0A2540]">{order.customer_name}</span>
                  <a
                    href={`https://wa.me/${order.customer_phone.replace(/[^0-9]/g, "")}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="flex items-center gap-1 rounded-lg bg-emerald-100 px-2 py-1 text-[10px] font-black text-emerald-700 transition hover:bg-emerald-200"
                    dir="ltr"
                  >
                    <Phone className="size-3" />
                    {order.customer_phone}
                  </a>
                </div>
                <span className={`rounded-full border px-2.5 py-1 text-[10px] font-black ${STATUS_STYLES[order.status] ?? STATUS_STYLES["new"]}`}>
                  {STATUS_AR[order.status] ?? order.status}
                </span>
              </div>

              {order.customer_address && (
                <p className="mt-1 text-[11px] text-slate-500">العنوان: {order.customer_address}</p>
              )}
              <p className="mt-0.5 flex items-center gap-1 text-[10px] text-slate-400">
                <Clock className="size-3" />
                {new Date(order.created_at).toLocaleString("ar-YE")}
              </p>

              <ul className="mt-2 space-y-1 border-t border-slate-200 pt-2">
                {order.items.map((item, idx) => (
                  <li key={idx} className="flex items-center justify-between text-[11px]">
                    <span className="text-slate-600">
                      {item.name}
                      <span className="mr-1.5 rounded bg-slate-200 px-1.5 py-0.5 text-[9px] font-black text-slate-600">
                        {item.store}
                      </span>
                      <span className="mr-1 font-black text-slate-500">×{item.qty}</span>
                    </span>
                    <span className="font-black text-[#0A2540]">${(item.price * item.qty).toFixed(2)}</span>
                  </li>
                ))}
              </ul>

              <div className="mt-2 flex flex-wrap items-center justify-between gap-2 border-t border-slate-200 pt-2">
                <span className="text-xs font-black text-[#EA580C]">
                  الإجمالي: ${order.total_usd.toFixed(2)}
                </span>
                <div className="flex flex-wrap gap-1.5">
                  {(["new", "reviewing", "purchased", "shipped", "delivered", "cancelled"] as const).map((s) => (
                    <button
                      key={s}
                      type="button"
                      disabled={updatingId === order.id || order.status === s}
                      onClick={() => void changeStatus(order.id, s)}
                      className={`rounded-lg px-2 py-1 text-[9px] font-black transition disabled:opacity-40 ${
                        order.status === s
                          ? STATUS_STYLES[s]
                          : "bg-white text-slate-500 ring-1 ring-slate-200 hover:bg-slate-100"
                      }`}
                    >
                      {STATUS_AR[s]}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
