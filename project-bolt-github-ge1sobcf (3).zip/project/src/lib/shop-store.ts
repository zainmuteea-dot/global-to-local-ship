import { useSyncExternalStore } from "react";
import type { CurrencyCode } from "./shop-data";

type CartItem = { productId: string; qty: number };
type FavoriteItem = string;

type ShopState = {
  cart: CartItem[];
  favorites: FavoriteItem[];
  currency: CurrencyCode;
};

const STORAGE_KEY = "alshamel-shop-state";

function load(): ShopState {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) {
      const parsed = JSON.parse(raw);
      return {
        cart: Array.isArray(parsed.cart) ? parsed.cart : [],
        favorites: Array.isArray(parsed.favorites) ? parsed.favorites : [],
        currency: (["YER", "SAR", "USD"] as CurrencyCode[]).includes(parsed.currency)
          ? parsed.currency
          : "YER",
      };
    }
  } catch {}
  return { cart: [], favorites: [], currency: "YER" };
}

let state: ShopState = typeof window === "undefined" ? { cart: [], favorites: [], currency: "YER" } : load();

const listeners = new Set<() => void>();

function emit() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
  } catch {}
  listeners.forEach((l) => l());
}

function setState(patch: Partial<ShopState>) {
  state = { ...state, ...patch };
  emit();
}

function subscribe(listener: () => void) {
  listeners.add(listener);
  return () => listeners.delete(listener);
}

export function useShopState(): ShopState {
  return useSyncExternalStore(
    subscribe,
    () => state,
    () => ({ cart: [], favorites: [], currency: "YER" as CurrencyCode }),
  );
}

export function addToCart(productId: string, qty = 1) {
  const existing = state.cart.find((i) => i.productId === productId);
  const cart = existing
    ? state.cart.map((i) => (i.productId === productId ? { ...i, qty: i.qty + qty } : i))
    : [...state.cart, { productId, qty }];
  setState({ cart });
}

export function removeFromCart(productId: string) {
  setState({ cart: state.cart.filter((i) => i.productId !== productId) });
}

export function changeQty(productId: string, delta: number) {
  const cart = state.cart
    .map((i) => (i.productId === productId ? { ...i, qty: Math.max(0, i.qty + delta) } : i))
    .filter((i) => i.qty > 0);
  setState({ cart });
}

export function clearCart() {
  setState({ cart: [] });
}

export function toggleFavorite(productId: string) {
  const favorites = state.favorites.includes(productId)
    ? state.favorites.filter((id) => id !== productId)
    : [...state.favorites, productId];
  setState({ favorites });
}

export function setCurrency(currency: CurrencyCode) {
  setState({ currency });
}

export function getCurrencyCode(): CurrencyCode {
  return state.currency;
}
