export type StoreId = "amazon" | "aliexpress" | "temu" | "trendyol" | "shein" | "ebay";

export type Product = {
  id: string;
  name: string;
  nameEn: string;
  store: StoreId;
  category: string;
  price: number; // USD
  oldPrice?: number; // USD
  rating: number;
  reviews: number;
  image: string;
  description: string;
  trending: boolean;
  dealOfDay: boolean;
};

export type StoreInfo = {
  id: StoreId;
  name: string;
  nameAr: string;
  gradient: string;
  brandColor: string;
  affiliateBase: string;
  searchTemplate?: string;
};

// ============================================================
// روابط الأفلييت: ضع روابطك الحقيقية في affiliateBase
// مثال: https://www.amazon.com/s?tag=YOUR-TAG-20&k=
// ============================================================
export const STORES: StoreInfo[] = [
  {
    id: "amazon",
    name: "Amazon",
    nameAr: "أمازون",
    gradient: "from-[#FF9900] to-[#E47911]",
    brandColor: "#FF9900",
    // Amazon Affiliate: ضع مكان للرابط
    affiliateBase: "https://www.amazon.com/s?tag=YOUR-AMAZON-TAG-20&k=",
    searchTemplate: "https://www.amazon.com/s?k=",
  },
  {
    id: "aliexpress",
    name: "AliExpress",
    nameAr: "علي إكسبريس",
    gradient: "from-[#E62E04] to-[#B91C1C]",
    brandColor: "#E62E04",
    // AliExpress Affiliate: ضع مكان للرابط
    affiliateBase: "https://www.aliexpress.com/wholesale?SearchText=",
    searchTemplate: "https://www.aliexpress.com/wholesale?SearchText=",
  },
  {
    id: "temu",
    name: "TEMU",
    nameAr: "تيمو",
    gradient: "from-[#FB7701] to-[#F97316]",
    brandColor: "#FB7701",
    affiliateBase: "",
    searchTemplate: "https://www.temu.com/search_result.html?search_key=",
  },
  {
    id: "trendyol",
    name: "Trendyol",
    nameAr: "ترينديول",
    gradient: "from-[#F27A1A] to-[#C2410C]",
    brandColor: "#F27A1A",
    affiliateBase: "",
    searchTemplate: "https://www.trendyol.com/sr?q=",
  },
  {
    id: "shein",
    name: "SHEIN",
    nameAr: "شي إن",
    gradient: "from-[#222222] to-[#555555]",
    brandColor: "#333333",
    affiliateBase: "",
    searchTemplate: "https://shein.com/pdsearch/",
  },
  {
    id: "ebay",
    name: "eBay",
    nameAr: "إيباي",
    gradient: "from-[#0064D2] to-[#00355F]",
    brandColor: "#0064D2",
    affiliateBase: "",
    searchTemplate: "https://www.ebay.com/sch/i.html?_nkw=",
  },
];

export const getStore = (id: StoreId) => STORES.find((s) => s.id === id)!;

/** يبني رابط الأفلييت الخاص بك للمنتج/البحث، ويرجع الرابط العادي إن لم يوجد أفلييت */
export function buildAffiliateLink(storeId: StoreId, query: string): string {
  const store = getStore(storeId);
  const q = encodeURIComponent(query);
  if (store.affiliateBase) return store.affiliateBase + q;
  return (store.searchTemplate ?? "https://www.google.com/search?q=") + q;
}

export const PRODUCTS: Product[] = [
  {
    id: "p1",
    name: "ساعة ذكية موديل برو 9",
    nameEn: "Smart Watch Pro 9 Series",
    store: "amazon",
    category: "إلكترونيات",
    price: 39.99,
    oldPrice: 79.99,
    rating: 4.7,
    reviews: 2431,
    image:
      "https://images.pexels.com/photos/29730990/pexels-photo-29730990.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description:
      "ساعة ذكية بشاشة AMOLED ساطعة، مراقبة نبضات القلب والأكسجين، مقاومة للماء، بطارية تدوم 7 أيام، متوافقة مع أندرويد وآيفون.",
    trending: true,
    dealOfDay: true,
  },
  {
    id: "p2",
    name: "جوال ذكي 5G شاشة 6.8 بوصة",
    nameEn: "Smartphone 5G 6.8 inch",
    store: "aliexpress",
    category: "إلكترونيات",
    price: 189.0,
    oldPrice: 249.0,
    rating: 4.5,
    reviews: 1876,
    image:
      "https://images.pexels.com/photos/7742500/pexels-photo-7742500.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description:
      "هاتف 5G بذاكرة 256 جيجابايت، كاميرا ثلاثية 108 ميجابكسل، بطارية 5000 مللي أمبير مع شحن سريع 67 واط.",
    trending: true,
    dealOfDay: false,
  },
  {
    id: "p3",
    name: "حذاء رياضي أبيض كلاسيك",
    nameEn: "White Classic Sneakers",
    store: "shein",
    category: "أحذية",
    price: 24.5,
    oldPrice: 45.0,
    rating: 4.6,
    reviews: 987,
    image:
      "https://images.pexels.com/photos/1456733/pexels-photo-1456733.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description:
      "حذاء رياضي مريح بنعل مطاطي مرن، خامة تسمح بالتهوية، مناسب للجري والاستخدام اليومي، متوفر بكل المقاسات.",
    trending: false,
    dealOfDay: true,
  },
  {
    id: "p4",
    name: "سماعات لاسلكية بخاصية إلغاء الضوضاء",
    nameEn: "Wireless Noise-Cancelling Headphones",
    store: "temu",
    category: "إلكترونيات",
    price: 19.99,
    oldPrice: 39.99,
    rating: 4.4,
    reviews: 3120,
    image:
      "https://images.pexels.com/photos/815494/pexels-photo-815494.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description:
      "سماعات بلوتوث 5.3 مع إلغاء نشط للضوضاء، صوت هاي ريز، بطارية 40 ساعة، وسائد أذن فائقة النعومة.",
    trending: true,
    dealOfDay: false,
  },
  {
    id: "p5",
    name: "حقيبة يد جلدية فاخرة",
    nameEn: "Luxury Leather Handbag",
    store: "trendyol",
    category: "أزياء",
    price: 34.0,
    oldPrice: 59.0,
    rating: 4.8,
    reviews: 654,
    image:
      "https://images.pexels.com/photos/7953286/pexels-photo-7953286.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description:
      "حقيبة يد نسائية من الجلد الطبيعي بتصميم أنيق، جيوب داخلية متعددة، حزام كتف قابل للتعديل، مثالية للمناسبات والعمل.",
    trending: false,
    dealOfDay: true,
  },
  {
    id: "p6",
    name: "عطر رجالي شرقي فخم 100 مل",
    nameEn: "Luxury Oriental Men's Perfume 100ml",
    store: "ebay",
    category: "عطور",
    price: 29.9,
    oldPrice: 55.0,
    rating: 4.9,
    reviews: 1422,
    image:
      "https://images.pexels.com/photos/15096784/pexels-photo-15096784.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description:
      "عطر شرقي فخم بثبات يصل إلى 12 ساعة، مزيج من العود والمسك والفانيليا، عبوة زجاجية فاخرة.",
    trending: true,
    dealOfDay: false,
  },
  {
    id: "p7",
    name: "طقم عقال ذهبي أنيق",
    nameEn: "Elegant Gold Necklace Set",
    store: "aliexpress",
    category: "إكسسوارات",
    price: 15.99,
    oldPrice: 32.0,
    rating: 4.3,
    reviews: 512,
    image:
      "https://images.pexels.com/photos/19869445/pexels-photo-19869445.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description:
      "عقال ذهبي بتصميم راقٍ لا يصدأ ولا يغير لونه، مناسب للهدايا والمناسبات، يأتي في علبة هدية.",
    trending: false,
    dealOfDay: false,
  },
  {
    id: "p8",
    name: "مجموعة مكياج احترافية 12 لون",
    nameEn: "Professional Makeup Palette 12 Colors",
    store: "shein",
    category: "تجميل",
    price: 12.5,
    oldPrice: 25.0,
    rating: 4.6,
    reviews: 2289,
    image:
      "https://images.pexels.com/photos/1327689/pexels-photo-1327689.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description:
      "باليت ظلال عيون بألوان ترابية ولامعة، تركيبة ناعمة سهلة الدمج، ثبات طويل، خالية من القساوة على الحيوانات.",
    trending: true,
    dealOfDay: true,
  },
  {
    id: "p9",
    name: "نظارة شمسية كلاسيك UV400",
    nameEn: "Classic Sunglasses UV400",
    store: "amazon",
    category: "إكسسوارات",
    price: 17.99,
    oldPrice: 35.0,
    rating: 4.5,
    reviews: 876,
    image:
      "https://images.pexels.com/photos/27353350/pexels-photo-27353350.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description:
      "نظارة شمسية بحماية كاملة من الأشعة فوق البنفسجية UV400، إطار خفيف متين، تناسب الرجال والنساء.",
    trending: false,
    dealOfDay: false,
  },
  {
    id: "p10",
    name: "ساعة ذكية رياضية للأطفال",
    nameEn: "Kids Sports Smartwatch",
    store: "temu",
    category: "إلكترونيات",
    price: 14.99,
    oldPrice: 28.0,
    rating: 4.2,
    reviews: 445,
    image:
      "https://images.pexels.com/photos/9584703/pexels-photo-9584703.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description:
      "ساعة ذكية للأطفال بألوان مبهجة، تتبع الخطوات والنوم، ألعاب تعليمية، بطارية تدوم 5 أيام.",
    trending: false,
    dealOfDay: false,
  },
  {
    id: "p11",
    name: "حذاء رياضي جري احترافي",
    nameEn: "Pro Running Shoes",
    store: "ebay",
    category: "أحذية",
    price: 42.0,
    oldPrice: 70.0,
    rating: 4.7,
    reviews: 1330,
    image:
      "https://images.pexels.com/photos/12628400/pexels-photo-12628400.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description:
      "حذاء جري احترافي بتقنية امتصاص الصدمات، نعل هوائي مرن، وزن خفيف جداً، مثالي للتمارين اليومية.",
    trending: true,
    dealOfDay: false,
  },
  {
    id: "p12",
    name: "أحمر شفاه مطفي طويل الثبات",
    nameEn: "Long-lasting Matte Lipstick",
    store: "trendyol",
    category: "تجميل",
    price: 6.99,
    oldPrice: 14.0,
    rating: 4.4,
    reviews: 1890,
    image:
      "https://images.pexels.com/photos/1213558/pexels-photo-1213558.jpeg?auto=compress&cs=tinysrgb&h=650&w=940",
    description:
      "أحمر شفاه بتركيبة مطفية مريحة، ثبات يصل إلى 8 ساعات، لا يجف الشفاه، متوفر بعشرات الدرجات.",
    trending: false,
    dealOfDay: true,
  },
];

export const CATEGORIES = [
  "الكل",
  "إلكترونيات",
  "أحذية",
  "أزياء",
  "عطور",
  "إكسسوارات",
  "تجميل",
];

export type CurrencyCode = "YER" | "SAR" | "USD";

export const CURRENCIES: Record<
  CurrencyCode,
  { code: CurrencyCode; name: string; symbol: string; rate: number }
> = {
  YER: { code: "YER", name: "ريال يمني", symbol: "ر.ي", rate: 530 },
  SAR: { code: "SAR", name: "ريال سعودي", symbol: "ر.س", rate: 3.75 },
  USD: { code: "USD", name: "دولار أمريكي", symbol: "$", rate: 1 },
};

export function formatPrice(usd: number, currency: CurrencyCode): string {
  const c = CURRENCIES[currency];
  const value = usd * c.rate;
  const formatted =
    c.code === "YER"
      ? Math.round(value).toLocaleString("ar-YE")
      : value.toLocaleString("en-US", { maximumFractionDigits: 2 });
  return c.code === "USD" ? `${c.symbol}${formatted}` : `${formatted} ${c.symbol}`;
}
