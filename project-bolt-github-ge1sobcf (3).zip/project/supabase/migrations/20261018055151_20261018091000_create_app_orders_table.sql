/*
# Create app_orders table (orders placed from the AL SHAMEL mobile app)

1. New Tables
- `app_orders`
  - `id` (uuid, primary key, auto-generated)
  - `customer_name` (text, customer name entered at checkout)
  - `customer_phone` (text, customer WhatsApp/phone number)
  - `customer_address` (text, optional delivery address / governorate)
  - `items` (jsonb, array of ordered products: id, name, store, price, qty)
  - `total_usd` (numeric, order total in USD before currency conversion)
  - `currency` (text, display currency selected by the customer: YER/SAR/USD)
  - `status` (text, order status: new / reviewing / purchased / shipped / delivered / cancelled)
  - `created_at` (timestamp, defaults to now)

2. Security
- Enable RLS on `app_orders`.
- INSERT: allowed for anon + authenticated (app users order without signing in).
- SELECT / UPDATE / DELETE: restricted to authenticated (admin panel) so customer
  orders are not publicly readable.

3. Notes
- Single-step order intake from the app cart; status managed from the admin panel.
*/

CREATE TABLE IF NOT EXISTS app_orders (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  customer_name text NOT NULL,
  customer_phone text NOT NULL,
  customer_address text,
  items jsonb NOT NULL DEFAULT '[]'::jsonb,
  total_usd numeric NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'YER',
  status text NOT NULL DEFAULT 'new',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE app_orders ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "anon_insert_app_orders" ON app_orders;
CREATE POLICY "anon_insert_app_orders" ON app_orders FOR INSERT
TO anon, authenticated WITH CHECK (true);

DROP POLICY IF EXISTS "auth_select_app_orders" ON app_orders;
CREATE POLICY "auth_select_app_orders" ON app_orders FOR SELECT
TO authenticated USING (true);

DROP POLICY IF EXISTS "auth_update_app_orders" ON app_orders;
CREATE POLICY "auth_update_app_orders" ON app_orders FOR UPDATE
TO authenticated USING (true) WITH CHECK (true);

DROP POLICY IF EXISTS "auth_delete_app_orders" ON app_orders;
CREATE POLICY "auth_delete_app_orders" ON app_orders FOR DELETE
TO authenticated USING (true);

CREATE INDEX IF NOT EXISTS idx_app_orders_created_at ON app_orders (created_at DESC);
