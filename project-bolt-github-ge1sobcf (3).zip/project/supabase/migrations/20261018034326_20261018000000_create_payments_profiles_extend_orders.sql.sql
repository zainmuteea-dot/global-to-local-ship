/*
# Create payments and profiles tables, extend orders for client statements

1. Plain-English explanation
- The /client-reports page (client account statements) reads orders and payments for each
  customer. The database was missing the `payments` and `profiles` tables entirely, and the
  `orders` table lacked the `user_id` and `total_amount` columns the app writes. Every read
  failed, so the page always showed zeros. This migration creates the missing tables and
  columns and locks them with row level security.

2. New tables
- `profiles`: one row per authenticated user (id, full_name, phone, created_at, updated_at).
  Written by the signup/login flows via upsert.
- `payments`: customer payment submissions (receipts) linked to an order by
  `order_tracking` / `tracking_code` and to the customer account by `user_id`.
  Columns: id, order_tracking, tracking_code, customer_name, phone, user_id, method,
  payment_method, wallet, amount, currency, receipt_image, status (pending/approved/
  rejected/cancelled), beneficiary_name, account_number, remaining_amount, reviewed_at,
  settled_at, cancelled_at, created_at, updated_at.

3. Modified tables
- `orders`: add `user_id` (owner account, nullable for legacy/anon orders), `total_amount`
  (order value, default 0), `paid_amount` (default 0), `remaining_amount` (default 0).
  No existing data is changed or removed.

4. Security (RLS)
- `profiles`: RLS enabled. Users read/update only their own row; admin/staff
  (via the trusted has_role RPC) can read all profiles to build customer lists.
  Inserts are restricted to the user's own id (used by the signup upsert).
- `payments`: RLS enabled. Users read only their own payments; admin/staff can read all.
  Users can insert their own payment submissions; only admin/staff can update or delete.
- `orders`: keeps its existing "authenticated can select/update/delete" policies; the new
  columns inherit that protection.

5. Important notes
- All statements are idempotent (IF NOT EXISTS / DROP POLICY IF EXISTS) and safe to re-run.
- No data is deleted; the migration only adds structure.
- Indexes added on payments(user_id), payments(status), payments(created_at),
  payments(order_tracking) for the statement queries.
*/

ALTER TABLE public.orders
  ADD COLUMN IF NOT EXISTS user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS total_amount numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS paid_amount numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS remaining_amount numeric NOT NULL DEFAULT 0;

CREATE INDEX IF NOT EXISTS orders_user_id_idx ON public.orders (user_id);

CREATE TABLE IF NOT EXISTS public.profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  full_name text,
  phone text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT, UPDATE ON public.profiles TO authenticated;

DROP POLICY IF EXISTS "Users read own profile" ON public.profiles;
CREATE POLICY "Users read own profile"
ON public.profiles FOR SELECT
TO authenticated
USING (auth.uid() = id);

DROP POLICY IF EXISTS "Staff read all profiles" ON public.profiles;
CREATE POLICY "Staff read all profiles"
ON public.profiles FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'));

DROP POLICY IF EXISTS "Users insert own profile" ON public.profiles;
CREATE POLICY "Users insert own profile"
ON public.profiles FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "Users update own profile" ON public.profiles;
CREATE POLICY "Users update own profile"
ON public.profiles FOR UPDATE
TO authenticated
USING (auth.uid() = id)
WITH CHECK (auth.uid() = id);

CREATE TABLE IF NOT EXISTS public.payments (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  order_tracking text,
  tracking_code text,
  customer_name text,
  phone text,
  user_id uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  method text,
  payment_method text,
  wallet text,
  amount numeric NOT NULL DEFAULT 0,
  currency text NOT NULL DEFAULT 'ر.س',
  receipt_image text,
  status text NOT NULL DEFAULT 'pending',
  beneficiary_name text,
  account_number text,
  remaining_amount numeric,
  reviewed_at timestamptz,
  settled_at timestamptz,
  cancelled_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;

GRANT SELECT, INSERT ON public.payments TO authenticated;
GRANT UPDATE, DELETE ON public.payments TO authenticated;

DROP POLICY IF EXISTS "Users read own payments" ON public.payments;
CREATE POLICY "Users read own payments"
ON public.payments FOR SELECT
TO authenticated
USING (auth.uid() = user_id);

DROP POLICY IF EXISTS "Staff read all payments" ON public.payments;
CREATE POLICY "Staff read all payments"
ON public.payments FOR SELECT
TO authenticated
USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'));

DROP POLICY IF EXISTS "Users insert own payments" ON public.payments;
CREATE POLICY "Users insert own payments"
ON public.payments FOR INSERT
TO authenticated
WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "Staff update payments" ON public.payments;
CREATE POLICY "Staff update payments"
ON public.payments FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'))
WITH CHECK (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'));

DROP POLICY IF EXISTS "Staff delete payments" ON public.payments;
CREATE POLICY "Staff delete payments"
ON public.payments FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'));

CREATE INDEX IF NOT EXISTS payments_user_id_idx ON public.payments (user_id);
CREATE INDEX IF NOT EXISTS payments_status_idx ON public.payments (status);
CREATE INDEX IF NOT EXISTS payments_created_at_idx ON public.payments (created_at DESC);
CREATE INDEX IF NOT EXISTS payments_order_tracking_idx ON public.payments (order_tracking);

DROP TRIGGER IF EXISTS payments_updated_at ON public.payments;
CREATE TRIGGER payments_updated_at
  BEFORE UPDATE ON public.payments
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();
