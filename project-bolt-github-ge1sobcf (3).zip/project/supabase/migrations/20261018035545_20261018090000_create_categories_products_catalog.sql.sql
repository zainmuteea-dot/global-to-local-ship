/*
# Create categories and products tables for the storefront catalog

1. Plain-English explanation
- The products management page (/products/manage) lets admins create sections (categories)
  and add products inside each section. Neither table existed in the database, so saving
  always failed. This migration creates both tables, protects them with row level security,
  and seeds the three default sections: شحن (shein), عروض (offer), محلي (local).

2. New tables
- `categories`: storefront sections.
  Columns: id (uuid PK), name (text), type (shein/local/offer), color (text, optional),
  icon (text, optional), sort_order (integer, ordering), created_at.
- `products`: items shown inside a section.
  Columns: id (uuid PK), category_id (uuid FK to categories, cascade delete), name (text),
  price (numeric), old_price (numeric, nullable — shown as crossed-out price),
  image_url (text, nullable), stock (integer), description (text, nullable),
  store (text — mirrors the category type), created_at, updated_at.

3. Security (RLS)
- RLS enabled on both tables.
- Reading the catalog is public (anon + authenticated) because customers browse it.
- Writing (insert/update/delete) is restricted to accounts holding the trusted
  admin or staff role, verified by the SECURITY DEFINER has_role RPC.

4. Important notes
- Idempotent: CREATE TABLE IF NOT EXISTS + DROP POLICY IF EXISTS, safe to re-run.
- Seeding inserts the default sections only when the table is empty, so re-running
  never duplicates data.
- Indexes: products(category_id), products(created_at), categories(sort_order).
*/

CREATE TABLE IF NOT EXISTS public.categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  type text NOT NULL DEFAULT 'shein' CHECK (type IN ('shein', 'local', 'offer')),
  color text,
  icon text,
  sort_order integer NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.products (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  category_id uuid NOT NULL REFERENCES public.categories(id) ON DELETE CASCADE,
  name text NOT NULL,
  price numeric NOT NULL DEFAULT 0,
  old_price numeric,
  image_url text,
  stock integer NOT NULL DEFAULT 0,
  description text,
  store text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;

GRANT SELECT ON public.categories TO anon, authenticated;
GRANT SELECT ON public.products TO anon, authenticated;
GRANT INSERT, UPDATE, DELETE ON public.categories TO authenticated;
GRANT INSERT, UPDATE, DELETE ON public.products TO authenticated;

DROP POLICY IF EXISTS "Public read categories" ON public.categories;
CREATE POLICY "Public read categories"
ON public.categories FOR SELECT
TO anon, authenticated
USING (true);

DROP POLICY IF EXISTS "Staff manage categories" ON public.categories;
CREATE POLICY "Staff manage categories"
ON public.categories FOR INSERT
TO authenticated
WITH CHECK (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'));

DROP POLICY IF EXISTS "Staff update categories" ON public.categories;
CREATE POLICY "Staff update categories"
ON public.categories FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'))
WITH CHECK (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'));

DROP POLICY IF EXISTS "Staff delete categories" ON public.categories;
CREATE POLICY "Staff delete categories"
ON public.categories FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'));

DROP POLICY IF EXISTS "Public read products" ON public.products;
CREATE POLICY "Public read products"
ON public.products FOR SELECT
TO anon, authenticated
USING (true);

DROP POLICY IF EXISTS "Staff insert products" ON public.products;
CREATE POLICY "Staff insert products"
ON public.products FOR INSERT
TO authenticated
WITH CHECK (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'));

DROP POLICY IF EXISTS "Staff update products" ON public.products;
CREATE POLICY "Staff update products"
ON public.products FOR UPDATE
TO authenticated
USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'))
WITH CHECK (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'));

DROP POLICY IF EXISTS "Staff delete products" ON public.products;
CREATE POLICY "Staff delete products"
ON public.products FOR DELETE
TO authenticated
USING (has_role(auth.uid(), 'admin') OR has_role(auth.uid(), 'staff'));

INSERT INTO public.categories (name, type, color, icon, sort_order)
SELECT 'شحن', 'shein', '#0F4C81', 'truck', 1
WHERE NOT EXISTS (SELECT 1 FROM public.categories);

INSERT INTO public.categories (name, type, color, icon, sort_order)
SELECT 'عروض', 'offer', '#D86616', 'tag', 2
WHERE NOT EXISTS (SELECT 1 FROM public.categories WHERE type = 'offer');

INSERT INTO public.categories (name, type, color, icon, sort_order)
SELECT 'محلي', 'local', '#10b981', 'store', 3
WHERE NOT EXISTS (SELECT 1 FROM public.categories WHERE type = 'local');

CREATE INDEX IF NOT EXISTS products_category_id_idx ON public.products (category_id);
CREATE INDEX IF NOT EXISTS products_created_at_idx ON public.products (created_at DESC);
CREATE INDEX IF NOT EXISTS categories_sort_order_idx ON public.categories (sort_order);

DROP TRIGGER IF EXISTS products_updated_at ON public.products;
CREATE TRIGGER products_updated_at
  BEFORE UPDATE ON public.products
  FOR EACH ROW
  EXECUTE FUNCTION update_updated_at();
